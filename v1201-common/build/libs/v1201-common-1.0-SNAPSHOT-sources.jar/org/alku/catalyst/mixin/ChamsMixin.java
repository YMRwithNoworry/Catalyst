package org.alku.catalyst.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public abstract class ChamsMixin {
    
    private static boolean catalyst$depthTestWasEnabled = false;
    
    @Inject(
        method = "render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        at = @At("HEAD")
    )
    private void beforeEntityRender(class_1297 entity, double x, double y, double z, float rotationYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (CatalystConfig.getInstance().chamsEnabled && shouldApplyChams(entity)) {
            catalyst$depthTestWasEnabled = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
            if (catalyst$depthTestWasEnabled) {
                RenderSystem.disableDepthTest();
            }
        }
    }
    
    @Inject(
        method = "render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
        at = @At("RETURN")
    )
    private void afterEntityRender(class_1297 entity, double x, double y, double z, float rotationYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (CatalystConfig.getInstance().chamsEnabled && shouldApplyChams(entity)) {
            if (catalyst$depthTestWasEnabled) {
                RenderSystem.enableDepthTest();
            }
        }
    }
    
    private static boolean shouldApplyChams(class_1297 entity) {
        if (entity instanceof class_1657) {
            return CatalystConfig.getInstance().chamsPlayers;
        }
        if (entity instanceof class_1429) {
            return CatalystConfig.getInstance().chamsAnimals;
        }
        if (entity instanceof class_1588) {
            return CatalystConfig.getInstance().chamsMonsters;
        }
        return false;
    }
}
