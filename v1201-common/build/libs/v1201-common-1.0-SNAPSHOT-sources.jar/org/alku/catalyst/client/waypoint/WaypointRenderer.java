package org.alku.catalyst.client.waypoint;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5321;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public class WaypointRenderer {
    
    public static void renderWaypoints(class_4587 poseStack, float partialTick) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        
        class_5321<class_1937> currentDimension = mc.field_1687.method_27983();
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        
        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();
        
        for (Waypoint wp : WaypointManager.getInstance().getWaypointsForDimension(currentDimension)) {
            renderWaypointBeam(poseStack, wp, cameraPos, partialTick, bufferSource);
        }
    }
    
    private static void renderWaypointBeam(class_4587 poseStack, Waypoint waypoint, class_243 cameraPos, float partialTick, class_4597 bufferSource) {
        class_2338 pos = waypoint.getPos();
        double x = pos.method_10263() - cameraPos.field_1352;
        double z = pos.method_10260() - cameraPos.field_1350;
        
        float r = ((waypoint.getColor() >> 16) & 0xFF) / 255.0f;
        float g = ((waypoint.getColor() >> 8) & 0xFF) / 255.0f;
        float b = (waypoint.getColor() & 0xFF) / 255.0f;
        
        poseStack.method_22903();
        poseStack.method_22904(x, 0, z);
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        
        class_289 tesselator = class_289.method_1348();
        class_287 buffer = tesselator.method_1349();
        
        RenderSystem.setShader(class_757::method_34540);
        
        double beamWidth = 0.2;
        int height = 256;
        
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        
        Matrix4f matrix = poseStack.method_23760().method_23761();
        
        float alpha = 0.5f;
        
        buffer.method_22918(matrix, (float)-beamWidth, height, (float)-beamWidth).method_22915(r, g, b, alpha).method_1344();
        buffer.method_22918(matrix, (float)beamWidth, height, (float)-beamWidth).method_22915(r, g, b, alpha).method_1344();
        buffer.method_22918(matrix, (float)beamWidth, height, (float)beamWidth).method_22915(r, g, b, alpha).method_1344();
        buffer.method_22918(matrix, (float)-beamWidth, height, (float)beamWidth).method_22915(r, g, b, alpha).method_1344();
        
        buffer.method_22918(matrix, (float)-beamWidth, 0, (float)-beamWidth).method_22915(r, g, b, 0.1f).method_1344();
        buffer.method_22918(matrix, (float)-beamWidth, 0, (float)beamWidth).method_22915(r, g, b, 0.1f).method_1344();
        buffer.method_22918(matrix, (float)beamWidth, 0, (float)beamWidth).method_22915(r, g, b, 0.1f).method_1344();
        buffer.method_22918(matrix, (float)beamWidth, 0, (float)-beamWidth).method_22915(r, g, b, 0.1f).method_1344();
        
        tesselator.method_1350();
        
        poseStack.method_22909();
        
        renderWaypointLabel(poseStack, waypoint, x, z, bufferSource);
    }
    
    private static void renderWaypointLabel(class_4587 poseStack, Waypoint waypoint, double x, double z, class_4597 bufferSource) {
        class_310 mc = class_310.method_1551();
        class_327 font = mc.field_1772;
        
        String initial = WaypointManager.getInstance().getDisplayInitial(waypoint);
        
        poseStack.method_22903();
        poseStack.method_22904(x, 260, z);
        poseStack.method_22907(mc.field_1773.method_19418().method_23767());
        poseStack.method_22905(-0.025f, -0.025f, 0.025f);
        
        float r = ((waypoint.getColor() >> 16) & 0xFF) / 255.0f;
        float g = ((waypoint.getColor() >> 8) & 0xFF) / 255.0f;
        float b = (waypoint.getColor() & 0xFF) / 255.0f;
        
        int textColor = ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255) | 0xFF000000;
        
        int textWidth = font.method_1727(initial);
        int textHeight = font.field_2000;
        int padding = 4;
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        
        class_289 tesselator = class_289.method_1348();
        class_287 buffer = tesselator.method_1349();
        
        RenderSystem.setShader(class_757::method_34540);
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        
        Matrix4f matrix = poseStack.method_23760().method_23761();
        
        float bgAlpha = 0.5f;
        buffer.method_22918(matrix, -textWidth / 2 - padding, -textHeight / 2 - padding, 0).method_22915(0, 0, 0, bgAlpha).method_1344();
        buffer.method_22918(matrix, textWidth / 2 + padding, -textHeight / 2 - padding, 0).method_22915(0, 0, 0, bgAlpha).method_1344();
        buffer.method_22918(matrix, textWidth / 2 + padding, textHeight / 2 + padding, 0).method_22915(0, 0, 0, bgAlpha).method_1344();
        buffer.method_22918(matrix, -textWidth / 2 - padding, textHeight / 2 + padding, 0).method_22915(0, 0, 0, bgAlpha).method_1344();
        
        tesselator.method_1350();
        
        font.method_27521(initial, -textWidth / 2.0f, -textHeight / 2.0f, textColor, false, matrix, bufferSource, class_327.class_6415.field_33993, 0, 15728880);
        
        poseStack.method_22909();
    }
}
