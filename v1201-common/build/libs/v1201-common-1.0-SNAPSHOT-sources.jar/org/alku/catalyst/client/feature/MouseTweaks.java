package org.alku.catalyst.client.feature;

import dev.architectury.event.EventResult;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_481;

public class MouseTweaks {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("MouseTweaks");
    
    private static boolean mouseLeftDown = false;
    private static boolean mouseRightDown = false;
    private static int lastMouseX = -1;
    private static int lastMouseY = -1;
    private static class_1735 lastHoveredSlot = null;
    private static boolean isDragging = false;
    private static int dragStartX = -1;
    private static int dragStartY = -1;
    private static int dragButton = -1;
    
    private static Map<class_1735, Integer> rmbSlotPassCounts = new HashMap<>();
    private static class_1799 rmbDragItem = class_1799.field_8037;
    
    private static class_1799 lmbDragItem = class_1799.field_8037;
    private static boolean lmbShiftDragMode = false;
    
    private static boolean rmbShiftDragMode = false;
    private static Set<Integer> processedSlots = new HashSet<>();
    
    public static void init() {
    }
    
    public static void tick(class_310 mc) {
        if (mc.field_1755 instanceof class_465) {
            double mouseX = mc.field_1729.method_1603();
            double mouseY = mc.field_1729.method_1604();
            
            double guiScale = mc.method_22683().method_4495();
            int scaledMouseX = (int) (mouseX / guiScale);
            int scaledMouseY = (int) (mouseY / guiScale);
            
            onMouseMove(mc, scaledMouseX, scaledMouseY);
        }
    }
    
    private static class_1735 getHoveredSlot(class_465<?> screen, int mouseX, int mouseY) {
        if (screen == null) {
            return null;
        }
        
        try {
            Field leftPosField = class_465.class.getDeclaredField("leftPos");
            Field topPosField = class_465.class.getDeclaredField("topPos");
            leftPosField.setAccessible(true);
            topPosField.setAccessible(true);
            
            int leftPos = leftPosField.getInt(screen);
            int topPos = topPosField.getInt(screen);
            
            int relX = mouseX - leftPos;
            int relY = mouseY - topPos;
            
            for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                class_1735 slot = screen.method_17577().method_7611(i);
                if (relX >= slot.field_7873 && relX < slot.field_7873 + 16 && relY >= slot.field_7872 && relY < slot.field_7872 + 16) {
                    return slot;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return null;
    }
    
    private static boolean isShiftKeyDown(class_310 mc) {
        return mc.field_1690.field_1832.method_1434() || 
               GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS ||
               GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }
    
    public static EventResult onMouseClicked(class_310 mc, int button, int action, int mods) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!(mc.field_1755 instanceof class_465) || !config.rmbTweak) {
            return EventResult.pass();
        }
        
        if (mc.field_1755 instanceof class_481) {
            return EventResult.pass();
        }
        
        double guiScale = mc.method_22683().method_4495();
        int currentMouseX = (int) (mc.field_1729.method_1603() / guiScale);
        int currentMouseY = (int) (mc.field_1729.method_1604() / guiScale);
        
        if (action == 1) {
            if (button == 0) {
                mouseLeftDown = true;
                dragButton = 0;
                dragStartX = currentMouseX;
                dragStartY = currentMouseY;
                lastMouseX = currentMouseX;
                lastMouseY = currentMouseY;
                processedSlots.clear();
                
                if (config.lmbTweakWithItem || config.lmbTweakWithoutItem) {
                    return handleLeftClickStart(mc, button, action, mods, currentMouseX, currentMouseY);
                }
            } else if (button == 1) {
                mouseRightDown = true;
                dragButton = 1;
                dragStartX = currentMouseX;
                dragStartY = currentMouseY;
                lastMouseX = currentMouseX;
                lastMouseY = currentMouseY;
                processedSlots.clear();
                
                return handleRightClickStart(mc, button, action, mods, currentMouseX, currentMouseY);
            }
        } else if (action == 0) {
            if (button == 0) {
                mouseLeftDown = false;
                if (isDragging && dragButton == 0) {
                    isDragging = false;
                    return handleLeftClickEnd(mc, button, action, mods);
                }
            } else if (button == 1) {
                mouseRightDown = false;
                if (isDragging && dragButton == 1) {
                    isDragging = false;
                    return handleRightClickEnd(mc, button, action, mods);
                }
            }
        }
        
        return EventResult.pass();
    }
    
    public static EventResult onMouseScrolled(class_310 mc, double scrollDelta) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!config.rmbTweak || !config.wheelTweak || !(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        if (mc.field_1755 instanceof class_481) {
            return EventResult.pass();
        }
        
        return handleWheelScroll(mc, scrollDelta);
    }
    
    public static void onMouseMove(class_310 mc, double mouseX, double mouseY) {
        int currentMouseX = (int) mouseX;
        int currentMouseY = (int) mouseY;
        
        if (!(mc.field_1755 instanceof class_465)) {
            lastMouseX = currentMouseX;
            lastMouseY = currentMouseY;
            return;
        }
        
        if (mc.field_1755 instanceof class_481) {
            lastMouseX = currentMouseX;
            lastMouseY = currentMouseY;
            return;
        }
        
        class_465<?> screen = (class_465<?>) mc.field_1755;
        
        if ((mouseLeftDown || mouseRightDown) && !isDragging) {
            int dx = Math.abs(currentMouseX - dragStartX);
            int dy = Math.abs(currentMouseY - dragStartY);
            
            if (dx > 3 || dy > 3) {
                isDragging = true;
            }
        }
        
        if (isDragging) {
            List<class_1735> slotsOnPath = getSlotsOnPath(screen, lastMouseX, lastMouseY, currentMouseX, currentMouseY);
            for (class_1735 slot : slotsOnPath) {
                if (slot != null) {
                    processSlot(mc, slot, screen);
                }
            }
        }
        
        lastHoveredSlot = getHoveredSlot(screen, currentMouseX, currentMouseY);
        lastMouseX = currentMouseX;
        lastMouseY = currentMouseY;
    }
    
    private static List<class_1735> getSlotsOnPath(class_465<?> screen, int x1, int y1, int x2, int y2) {
        List<class_1735> slots = new ArrayList<>();
        Set<Integer> seenIndices = new HashSet<>();
        
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int steps = Math.max(dx, dy) + 1;
        
        for (int i = 0; i <= steps; i++) {
            float t = steps == 0 ? 0 : (float) i / steps;
            int x = (int) (x1 + (x2 - x1) * t);
            int y = (int) (y1 + (y2 - y1) * t);
            
            class_1735 slot = getHoveredSlot(screen, x, y);
            if (slot != null && !seenIndices.contains(slot.field_7874)) {
                slots.add(slot);
                seenIndices.add(slot.field_7874);
            }
        }
        
        return slots;
    }
    
    private static void processSlot(class_310 mc, class_1735 slot, class_465<?> screen) {
        CatalystConfig config = CatalystConfig.getInstance();
        boolean shiftDown = isShiftKeyDown(mc);
        
        if (dragButton == 0) {
            if (lmbShiftDragMode && config.lmbTweakWithoutItem) {
                if (shiftDown && !slot.method_7677().method_7960()) {
                    performShiftClick(mc, slot);
                }
            } else if (!lmbDragItem.method_7960() && config.lmbTweakWithItem) {
                class_1799 slotItem = slot.method_7677();
                if (!slotItem.method_7960() && class_1799.method_31577(lmbDragItem, slotItem)) {
                    if (shiftDown) {
                        performShiftClick(mc, slot);
                    } else {
                        performMerge(mc, slot);
                    }
                }
            }
        } else if (dragButton == 1) {
            if (rmbShiftDragMode) {
                if (shiftDown && !slot.method_7677().method_7960()) {
                    performThrow(mc, slot);
                }
            } else if (!rmbDragItem.method_7960()) {
                if (slot.method_7680(rmbDragItem)) {
                    rmbSlotPassCounts.put(slot, rmbSlotPassCounts.getOrDefault(slot, 0) + 1);
                }
            }
        }
    }
    
    private static EventResult handleLeftClickStart(class_310 mc, int button, int action, int mods, int mouseX, int mouseY) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        boolean shiftDown = isShiftKeyDown(mc);
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, mouseX, mouseY);
        
        lmbShiftDragMode = false;
        lmbDragItem = class_1799.field_8037;
        
        if (shiftDown && config.lmbTweakWithoutItem) {
            lmbShiftDragMode = true;
            if (hoveredSlot != null && !hoveredSlot.method_7677().method_7960()) {
                performShiftClick(mc, hoveredSlot);
            }
            return EventResult.interruptDefault();
        }
        
        if (hoveredSlot != null && mc.field_1761 != null) {
            class_1703 menu = mc.field_1724.field_7512;
            int containerId = menu.field_7763;
            
            class_1799 carriedBefore = menu.method_34255();
            
            if (carriedBefore.method_7960()) {
                if (config.lmbTweakWithItem) {
                    mc.field_1761.method_2906(containerId, hoveredSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
                    lmbDragItem = menu.method_34255();
                } else {
                    return EventResult.pass();
                }
            } else {
                lmbDragItem = carriedBefore;
            }
        } else {
            lmbDragItem = mc.field_1724.field_7512.method_34255();
        }
        
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickStart(class_310 mc, int button, int action, int mods, int mouseX, int mouseY) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        boolean shiftDown = isShiftKeyDown(mc);
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, mouseX, mouseY);
        
        rmbShiftDragMode = false;
        rmbDragItem = class_1799.field_8037;
        
        if (shiftDown && config.rmbTweak) {
            rmbShiftDragMode = true;
            if (hoveredSlot != null && !hoveredSlot.method_7677().method_7960()) {
                performThrow(mc, hoveredSlot);
            }
            return EventResult.interruptDefault();
        }
        
        if (hoveredSlot != null && mc.field_1761 != null) {
            class_1703 menu = mc.field_1724.field_7512;
            int containerId = menu.field_7763;
            
            class_1799 carriedBefore = menu.method_34255();
            
            mc.field_1761.method_2906(containerId, hoveredSlot.field_7874, 1, class_1713.field_7790, mc.field_1724);
            
            rmbDragItem = menu.method_34255();
            
            if (!class_1799.method_7973(carriedBefore, rmbDragItem)) {
                rmbSlotPassCounts.put(hoveredSlot, 1);
            }
        } else {
            rmbDragItem = mc.field_1724.field_7512.method_34255();
        }
        
        rmbSlotPassCounts.clear();
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleLeftClickEnd(class_310 mc, int button, int action, int mods) {
        lmbDragItem = class_1799.field_8037;
        lmbShiftDragMode = false;
        processedSlots.clear();
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickEnd(class_310 mc, int button, int action, int mods) {
        rmbShiftDragMode = false;
        processedSlots.clear();
        
        if (rmbSlotPassCounts.isEmpty()) {
            return EventResult.pass();
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        for (Map.Entry<class_1735, Integer> entry : rmbSlotPassCounts.entrySet()) {
            class_1735 slot = entry.getKey();
            int passCount = entry.getValue();
            
            if (passCount <= 0) {
                continue;
            }
            
            for (int i = 0; i < passCount; i++) {
                if (mc.field_1761 != null) {
                    class_1799 carriedBefore = menu.method_34255();
                    if (carriedBefore.method_7960()) {
                        break;
                    }
                    
                    mc.field_1761.method_2906(containerId, slot.field_7874, 1, class_1713.field_7790, mc.field_1724);
                    
                    class_1799 carriedAfter = menu.method_34255();
                    if (class_1799.method_7973(carriedBefore, carriedAfter)) {
                        break;
                    }
                }
            }
        }
        
        rmbSlotPassCounts.clear();
        rmbDragItem = class_1799.field_8037;
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleWheelScroll(class_310 mc, double scrollDelta) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        if (hoveredSlot == null || mc.field_1761 == null) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean isPush = scrollDelta < 0;
        
        if (config.wheelScrollDirection == 1) {
            isPush = !isPush;
        } else if (config.wheelScrollDirection == 2) {
            if (hoveredSlot.field_7871 == mc.field_1724.method_31548()) {
                isPush = scrollDelta < 0;
            } else {
                isPush = scrollDelta > 0;
            }
        }
        
        if (isPush) {
            performWheelPush(mc, hoveredSlot);
        } else {
            performWheelPull(mc, hoveredSlot);
        }
        
        return EventResult.interruptDefault();
    }
    
    private static void performShiftClick(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        mc.field_1761.method_2906(containerId, slot.field_7874, 0, class_1713.field_7794, mc.field_1724);
    }
    
    private static void performThrow(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        mc.field_1761.method_2906(containerId, slot.field_7874, 1, class_1713.field_7795, mc.field_1724);
    }
    
    private static void performRmbPlace(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        mc.field_1761.method_2906(containerId, slot.field_7874, 1, class_1713.field_7790, mc.field_1724);
        
        rmbDragItem = menu.method_34255();
    }
    
    private static void performMerge(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        class_1799 slotItem = slot.method_7677();
        class_1799 carried = menu.method_34255();
        
        if (carried.method_7960() || !class_1799.method_31577(carried, slotItem)) {
            return;
        }
        
        int maxStackSize = carried.method_7914();
        int totalAmount = carried.method_7947() + slotItem.method_7947();
        
        if (totalAmount <= maxStackSize) {
            mc.field_1761.method_2906(containerId, slot.field_7874, 0, class_1713.field_7790, mc.field_1724);
        } else {
            int remaining = totalAmount - maxStackSize;
            slotItem.method_7939(remaining);
            carried.method_7939(maxStackSize);
            slot.method_7668();
        }
        
        lmbDragItem = menu.method_34255();
    }
    
    private static void performWheelPush(class_310 mc, class_1735 sourceSlot) {
        if (sourceSlot.field_7871 != mc.field_1724.method_31548()) {
            return;
        }
        
        class_1799 sourceItem = sourceSlot.method_7677();
        if (sourceItem.method_7960()) {
            return;
        }
        
        class_1735 targetSlot = findWheelTargetSlot(mc, sourceItem, false);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static void performWheelPull(class_310 mc, class_1735 sourceSlot) {
        if (sourceSlot.field_7871 == mc.field_1724.method_31548()) {
            return;
        }
        
        class_1799 sourceItem = sourceSlot.method_7677();
        if (sourceItem.method_7960()) {
            return;
        }
        
        class_1735 targetSlot = findWheelTargetSlot(mc, sourceItem, true);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static class_1735 findWheelTargetSlot(class_310 mc, class_1799 item, boolean searchPlayerInventory) {
        class_1703 menu = mc.field_1724.field_7512;
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean reverse = config.wheelSearchOrder == 1;
        
        int start = reverse ? menu.field_7761.size() - 1 : 0;
        int end = reverse ? -1 : menu.field_7761.size();
        int step = reverse ? -1 : 1;
        
        for (int i = start; i != end; i += step) {
            class_1735 slot = menu.method_7611(i);
            boolean isPlayerInventory = slot.field_7871 == mc.field_1724.method_31548();
            
            if (searchPlayerInventory != isPlayerInventory) {
                continue;
            }
            
            if (slot.method_7680(item)) {
                class_1799 slotItem = slot.method_7677();
                if (slotItem.method_7960()) {
                    return slot;
                } else if (class_1799.method_31577(item, slotItem) && slotItem.method_7947() < slotItem.method_7914()) {
                    return slot;
                }
            }
        }
        
        return null;
    }
    
    private static void transferItem(class_310 mc, class_1735 sourceSlot, class_1735 targetSlot) {
        if (mc.field_1761 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        class_1799 sourceItem = sourceSlot.method_7677();
        class_1799 targetItem = targetSlot.method_7677();
        
        if (targetItem.method_7960()) {
            mc.field_1761.method_2906(containerId, sourceSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
            mc.field_1761.method_2906(containerId, targetSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
        } else if (class_1799.method_31577(sourceItem, targetItem)) {
            int maxStackSize = sourceItem.method_7914();
            int total = sourceItem.method_7947() + targetItem.method_7947();
            
            if (total <= maxStackSize) {
                mc.field_1761.method_2906(containerId, sourceSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
                mc.field_1761.method_2906(containerId, targetSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
            } else {
                int remaining = total - maxStackSize;
                sourceItem.method_7939(remaining);
                targetItem.method_7939(maxStackSize);
                sourceSlot.method_7668();
                targetSlot.method_7668();
            }
        }
    }
}
