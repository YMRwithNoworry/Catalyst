package org.alku.catalyst.client.feature;

import net.minecraft.class_310;
import org.alku.catalyst.config.CatalystConfig;

public class GammaOverride {
    private static double originalGamma = -1;
    private static boolean wasEnabled = false;
    private static final double MAX_GAMMA = 10000.0;
    
    public static void tick(class_310 mc) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (config.gammaOverrideEnabled) {
            if (!wasEnabled) {
                originalGamma = mc.field_1690.method_42473().method_41753();
                wasEnabled = true;
            }
            
            double targetGamma = config.gammaValue;
            if (config.nightVisionMode) {
                targetGamma = Math.max(config.gammaValue, MAX_GAMMA);
            }
            targetGamma = Math.min(targetGamma, MAX_GAMMA);
            mc.field_1690.method_42473().method_41748(targetGamma);
        } else {
            if (wasEnabled && originalGamma >= 0) {
                mc.field_1690.method_42473().method_41748(originalGamma);
                wasEnabled = false;
            }
        }
    }
    
    public static void onDisable(class_310 mc) {
        if (wasEnabled && originalGamma >= 0) {
            mc.field_1690.method_42473().method_41748(originalGamma);
            wasEnabled = false;
        }
    }
    
    public static void setGamma(class_310 mc, double value) {
        double targetGamma = Math.min(Math.max(0, value), MAX_GAMMA);
        mc.field_1690.method_42473().method_41748(targetGamma);
    }
}
