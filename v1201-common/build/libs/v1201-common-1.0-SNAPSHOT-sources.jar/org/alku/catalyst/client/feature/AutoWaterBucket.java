package org.alku.catalyst.client.feature;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import org.alku.catalyst.config.CatalystConfig;

public class AutoWaterBucket {
    private enum State {
        IDLE,
        FALLING,
        NEED_PLACE_WATER,
        WATER_PLACED,
        COLLECTED
    }
    
    private static State state = State.IDLE;
    private static int waterBucketSlot = -1;
    private static int originalSelectedSlot = -1;
    private static class_1799 originalSlotItem = class_1799.field_8037;
    private static class_2338 waterPlacedPos = null;
    private static long lastActionTime = 0;
    private static boolean waterPlaced = false;
    private static float originalPitch = 0;
    private static float originalYaw = 0;
    private static double savedGroundHeight = 0;
    
    public static void tick(class_310 mc) {
        if (!CatalystConfig.getInstance().autoWaterBucketEnabled) {
            reset();
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return;
        }
        
        switch (state) {
            case IDLE:
                handleIdle(mc, player);
                break;
            case FALLING:
                handleFalling(mc, player);
                break;
            case NEED_PLACE_WATER:
                handleNeedPlaceWater(mc, player);
                break;
            case WATER_PLACED:
                handleWaterPlaced(mc, player);
                break;
            case COLLECTED:
                handleCollected(mc, player);
                break;
        }
    }
    
    private static void handleIdle(class_310 mc, class_746 player) {
        if (player.method_24828() || player.method_5799() || player.method_5715()) {
            return;
        }
        
        boolean isFalling = player.method_18798().field_1351 < -0.1;
        boolean willTakeDamage = player.field_6017 > 3.0f;
        
        if (isFalling && willTakeDamage) {
            waterBucketSlot = findWaterBucket(player);
            if (waterBucketSlot >= 0) {
                originalSelectedSlot = player.method_31548().field_7545;
                originalSlotItem = player.method_31548().method_5438(originalSelectedSlot).method_7972();
                originalPitch = player.method_36455();
                originalYaw = player.method_36454();
                
                player.method_31548().field_7545 = waterBucketSlot;
                
                state = State.FALLING;
                waterPlaced = false;
            }
        }
    }
    
    private static void handleFalling(class_310 mc, class_746 player) {
        if (player.method_24828() && !player.method_5799()) {
            if (!waterPlaced) {
                reset();
                return;
            }
            collectWaterAndRestore(mc, player);
            state = State.COLLECTED;
            lastActionTime = System.currentTimeMillis();
            return;
        }
        
        if (player.method_5799()) {
            collectWaterAndRestore(mc, player);
            state = State.COLLECTED;
            lastActionTime = System.currentTimeMillis();
            return;
        }
        
        if (!waterPlaced) {
            double groundHeight = findGroundHeight(mc);
            double currentHeight = player.method_23318();
            double fallDistance = currentHeight - groundHeight;
            
            if (fallDistance < 4 && fallDistance > 1) {
                savedGroundHeight = groundHeight;
                player.method_36457(90.0f);
                state = State.NEED_PLACE_WATER;
            }
        }
    }
    
    private static void handleNeedPlaceWater(class_310 mc, class_746 player) {
        if (player.method_24828() && !player.method_5799()) {
            if (!waterPlaced) {
                reset();
                return;
            }
            collectWaterAndRestore(mc, player);
            state = State.COLLECTED;
            lastActionTime = System.currentTimeMillis();
            return;
        }
        
        if (player.method_5799()) {
            collectWaterAndRestore(mc, player);
            state = State.COLLECTED;
            lastActionTime = System.currentTimeMillis();
            return;
        }
        
        placeWaterAtGround(mc, player, savedGroundHeight);
        waterPlaced = true;
        waterPlacedPos = new class_2338(player.method_31477(), (int)savedGroundHeight - 1, player.method_31479());
        state = State.WATER_PLACED;
    }
    
    private static void handleWaterPlaced(class_310 mc, class_746 player) {
        if (player.method_5799() || player.method_24828()) {
            collectWaterAndRestore(mc, player);
            state = State.COLLECTED;
            lastActionTime = System.currentTimeMillis();
        }
    }
    
    private static void handleCollected(class_310 mc, class_746 player) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastActionTime > 50) {
            restoreItems(player);
            reset();
        }
    }
    
    private static void placeWaterAtGround(class_310 mc, class_746 player, double groundHeight) {
        int x = player.method_31477();
        int z = player.method_31479();
        int y = (int) Math.floor(groundHeight) - 1;
        
        class_2338 placePos = new class_2338(x, y, z);
        
        class_3965 hitResult = new class_3965(
            new class_243(x + 0.5, y + 1.0, z + 0.5),
            class_2350.field_11036,
            placePos,
            false
        );
        
        class_1269 result = mc.field_1761.method_2896(player, class_1268.field_5808, hitResult);
        
        if (result == class_1269.field_5811 || result == class_1269.field_5814) {
            mc.field_1761.method_2919(player, class_1268.field_5808);
        }
    }
    
    private static void collectWaterAndRestore(class_310 mc, class_746 player) {
        int bucketSlot = findBucket(player);
        if (bucketSlot >= 0) {
            player.method_31548().field_7545 = bucketSlot;
            
            class_2338 targetPos = waterPlacedPos != null ? waterPlacedPos : player.method_24515().method_10074();
            
            player.method_36457(90.0f);
            
            class_3965 hitResult = new class_3965(
                new class_243(targetPos.method_10263() + 0.5, targetPos.method_10264() + 1.0, targetPos.method_10260() + 0.5),
                class_2350.field_11036,
                targetPos,
                false
            );
            
            mc.field_1761.method_2896(player, class_1268.field_5808, hitResult);
        }
        
        player.method_36457(originalPitch);
        player.method_36456(originalYaw);
    }
    
    private static void restoreItems(class_746 player) {
        if (waterBucketSlot < 0 || originalSelectedSlot < 0) {
            return;
        }
        
        int currentBucketSlot = findWaterBucket(player);
        
        if (currentBucketSlot >= 0 && currentBucketSlot != waterBucketSlot) {
            class_1799 bucketStack = player.method_31548().method_5438(currentBucketSlot);
            class_1799 otherStack = player.method_31548().method_5438(waterBucketSlot);
            
            player.method_31548().method_5447(waterBucketSlot, bucketStack);
            player.method_31548().method_5447(currentBucketSlot, otherStack);
        }
        
        player.method_31548().field_7545 = originalSelectedSlot;
    }
    
    private static int findWaterBucket(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8705) {
                return i;
            }
        }
        return -1;
    }
    
    private static int findBucket(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8550) {
                return i;
            }
        }
        return -1;
    }
    
    private static double findGroundHeight(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return player != null ? player.method_23318() : 0;
        }
        
        class_2338 pos = player.method_24515();
        
        for (int y = pos.method_10264(); y > mc.field_1687.method_31607(); y--) {
            class_2338 checkPos = new class_2338(pos.method_10263(), y, pos.method_10260());
            class_2680 state = mc.field_1687.method_8320(checkPos);
            
            if (!state.method_26215() && !state.method_27852(class_2246.field_10382) && !state.method_27852(class_2246.field_10164)) {
                return y + 1;
            }
        }
        
        return mc.field_1687.method_31607();
    }
    
    private static void reset() {
        state = State.IDLE;
        waterBucketSlot = -1;
        originalSelectedSlot = -1;
        originalSlotItem = class_1799.field_8037;
        waterPlacedPos = null;
        waterPlaced = false;
        savedGroundHeight = 0;
    }
}
