package org.alku.catalyst.client.feature;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.alku.catalyst.config.CatalystConfig;

public class AutoTool {
    private static int originalSlot = -1;
    private static class_2338 lastBlockPos = null;
    private static boolean wasBreaking = false;
    
    public static void checkAndSwitch(class_310 mc) {
        if (!CatalystConfig.getInstance().autoToolEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return;
        }
        
        if (mc.field_1765 instanceof net.minecraft.class_3965 blockHitResult) {
            class_2338 pos = blockHitResult.method_17777();
            class_2680 state = mc.field_1687.method_8320(pos);
            
            if (!state.method_26215()) {
                if (CatalystConfig.getInstance().autoToolRestore && !wasBreaking) {
                    originalSlot = player.method_31548().field_7545;
                }
                
                int bestSlot = findBestToolSlot(player, state);
                if (bestSlot >= 0 && bestSlot != player.method_31548().field_7545) {
                    player.method_31548().field_7545 = bestSlot;
                    lastBlockPos = pos;
                }
            }
        }
    }
    
    public static void tick(class_310 mc) {
        if (!CatalystConfig.getInstance().autoToolEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return;
        }
        
        boolean isBreaking = mc.field_1690.field_1886.method_1434();
        
        if (isBreaking) {
            wasBreaking = true;
        } else {
            if (wasBreaking && originalSlot >= 0 && CatalystConfig.getInstance().autoToolRestore) {
                player.method_31548().field_7545 = originalSlot;
                originalSlot = -1;
                lastBlockPos = null;
            }
            wasBreaking = false;
        }
    }
    
    private static int findBestToolSlot(class_746 player, class_2680 state) {
        class_1661 inventory = player.method_31548();
        
        int lockedSlot = CatalystConfig.getInstance().autoToolLockedSlot;
        if (lockedSlot >= 0 && lockedSlot < 9) {
            return lockedSlot;
        }
        
        int bestSlot = inventory.field_7545;
        float bestSpeed = player.method_6047().method_7924(state);
        
        for (int i = 0; i < 9; i++) {
            if (i == inventory.field_7545) {
                continue;
            }
            
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) {
                continue;
            }
            
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }
        
        return bestSlot;
    }
}
