package org.alku.catalyst.client.feature;

import net.minecraft.class_1268;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import org.alku.catalyst.config.CatalystConfig;

public class AutoDoor {
    private static long lastToggleTime = 0;
    private static final long COOLDOWN = 500;
    
    public static void tick(class_310 mc) {
        if (!CatalystConfig.getInstance().autoDoorEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastToggleTime < COOLDOWN) {
            return;
        }
        
        class_2338 playerPos = player.method_24515();
        
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 checkPos = playerPos.method_10093(direction);
            class_2680 state = mc.field_1687.method_8320(checkPos);
            
            if (state.method_26204() instanceof class_2323) {
                boolean isOpen = state.method_11654(class_2323.field_10945);
                class_243 playerEyePos = player.method_33571();
                class_243 doorCenter = class_243.method_24953(checkPos);
                
                double distance = playerEyePos.method_1022(doorCenter);
                
                if (distance < 2.5) {
                    boolean shouldOpen = isPlayerApproachingDoor(player, checkPos, direction);
                    
                    if (shouldOpen != isOpen) {
                        class_3965 hitResult = new class_3965(
                            class_243.method_24953(checkPos),
                            direction.method_10153(),
                            checkPos,
                            false
                        );
                        mc.field_1761.method_2896(player, class_1268.field_5808, hitResult);
                        lastToggleTime = currentTime;
                        return;
                    }
                }
            }
        }
    }
    
    private static boolean isPlayerApproachingDoor(class_746 player, class_2338 doorPos, class_2350 doorDirection) {
        class_243 playerPos = player.method_33571();
        class_243 doorCenter = class_243.method_24953(doorPos);
        
        class_243 toDoor = doorCenter.method_1020(playerPos).method_1029();
        class_243 playerLook = player.method_5720();
        
        double dot = toDoor.method_1026(playerLook);
        
        return dot > 0.5;
    }
}
