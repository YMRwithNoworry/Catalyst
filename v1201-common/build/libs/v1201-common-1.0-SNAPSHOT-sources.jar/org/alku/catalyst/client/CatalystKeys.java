package org.alku.catalyst.client;

import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class CatalystKeys {
    public static final String KEY_CATEGORY = "key.categories.catalyst";
    
    public static class_304 TOGGLE_AUTO_SPRINT;
    public static class_304 TOGGLE_AUTO_SWIM;
    public static class_304 TOGGLE_GAMMA_OVERRIDE;
    public static class_304 TOGGLE_AUTO_TOOL;
    public static class_304 TOGGLE_AUTO_WEAPON;
    public static class_304 OPEN_CONFIG;
    public static class_304 SORT_INVENTORY;
    
    public static void register() {
        TOGGLE_AUTO_SPRINT = new class_304(
            "key.catalyst.toggle_auto_sprint",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            KEY_CATEGORY
        );
        
        TOGGLE_AUTO_SWIM = new class_304(
            "key.catalyst.toggle_auto_swim",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            KEY_CATEGORY
        );
        
        TOGGLE_GAMMA_OVERRIDE = new class_304(
            "key.catalyst.toggle_gamma_override",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            KEY_CATEGORY
        );
        
        TOGGLE_AUTO_TOOL = new class_304(
            "key.catalyst.toggle_auto_tool",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            KEY_CATEGORY
        );
        
        TOGGLE_AUTO_WEAPON = new class_304(
            "key.catalyst.toggle_auto_weapon",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            KEY_CATEGORY
        );
        
        OPEN_CONFIG = new class_304(
            "key.catalyst.open_config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_J,
            KEY_CATEGORY
        );
        
        SORT_INVENTORY = new class_304(
            "key.catalyst.sort_inventory",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            KEY_CATEGORY
        );
        
        KeyMappingRegistry.register(TOGGLE_AUTO_SPRINT);
        KeyMappingRegistry.register(TOGGLE_AUTO_SWIM);
        KeyMappingRegistry.register(TOGGLE_GAMMA_OVERRIDE);
        KeyMappingRegistry.register(TOGGLE_AUTO_TOOL);
        KeyMappingRegistry.register(TOGGLE_AUTO_WEAPON);
        KeyMappingRegistry.register(OPEN_CONFIG);
        KeyMappingRegistry.register(SORT_INVENTORY);
    }
}
