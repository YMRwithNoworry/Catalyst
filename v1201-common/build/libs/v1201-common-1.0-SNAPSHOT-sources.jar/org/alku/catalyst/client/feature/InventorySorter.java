package org.alku.catalyst.client.feature;

import org.alku.catalyst.config.CatalystConfig;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class InventorySorter {
    
    private static boolean sorting = false;
    
    public static void sortCurrentContainer(class_310 mc) {
        if (!CatalystConfig.getInstance().inventorySorterEnabled || sorting) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1761 == null) {
            return;
        }
        
        class_1703 container = player.field_7512;
        if (container == null) {
            return;
        }
        
        System.out.println("[Catalyst] Sorting container: " + container.getClass().getSimpleName() + " (inventorySorterEnabled=" + CatalystConfig.getInstance().inventorySorterEnabled + ", autoSortOnOpen=" + CatalystConfig.getInstance().autoSortOnOpen + ")");
        
        sorting = true;
        try {
            int containerId = container.field_7763;
            
            if (container instanceof class_1723) {
                sortPlayerInventory(mc, player, container, containerId);
            } else {
                sortOpenContainer(mc, player, container, containerId);
            }
        } finally {
            sorting = false;
        }
    }
    
    public static void tick(class_310 mc) {
    }
    
    private static void clickSlot(class_310 mc, int containerId, int slotIndex, int button, class_1713 clickType) {
        if (mc.field_1724 != null && mc.field_1761 != null) {
            mc.field_1761.method_2906(containerId, slotIndex, button, clickType, mc.field_1724);
        }
    }
    
    public static void sortPlayerInventory(class_310 mc, class_746 player, class_1703 container, int containerId) {
        List<Integer> mainInventorySlots = new ArrayList<>();
        List<Integer> hotbarSlots = new ArrayList<>();
        
        class_1263 playerInventory = player.method_31548();
        
        for (int i = 0; i < container.field_7761.size(); i++) {
            class_1735 slot = container.method_7611(i);
            if (slot.field_7871 == playerInventory) {
                int containerSlot = slot.method_34266();
                if (containerSlot >= 0 && containerSlot < 9) {
                    hotbarSlots.add(i);
                } else if (containerSlot >= 9 && containerSlot < 36) {
                    mainInventorySlots.add(i);
                }
            }
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        doSort(mc, container, containerId, mainInventorySlots, config.sortMode);
        
        if (config.sortHotbar) {
            doSort(mc, container, containerId, hotbarSlots, config.sortMode);
        }
    }
    
    public static void sortOpenContainer(class_310 mc, class_746 player, class_1703 container, int containerId) {
        List<Integer> containerSlots = new ArrayList<>();
        List<Integer> playerInvSlots = new ArrayList<>();
        List<Integer> playerHotbarSlots = new ArrayList<>();
        
        class_1263 playerInventory = player.method_31548();
        
        for (int i = 0; i < container.field_7761.size(); i++) {
            class_1735 slot = container.method_7611(i);
            if (slot.field_7871 == playerInventory) {
                int containerSlot = slot.method_34266();
                if (containerSlot >= 0 && containerSlot < 9) {
                    playerHotbarSlots.add(i);
                } else if (containerSlot >= 9 && containerSlot < 36) {
                    playerInvSlots.add(i);
                }
            } else if (slot.field_7871 != null && slot.field_7871 != playerInventory) {
                containerSlots.add(i);
            }
        }
        
        System.out.println("[Catalyst] sortOpenContainer: totalSlots=" + container.field_7761.size() + ", containerSlots=" + containerSlots.size() + ", playerInvSlots=" + playerInvSlots.size() + ", playerHotbarSlots=" + playerHotbarSlots.size());
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        doSort(mc, container, containerId, containerSlots, config.sortMode);
        
        if (config.sortPlayerInventoryInContainer) {
            doSort(mc, container, containerId, playerInvSlots, config.sortMode);
            if (config.sortHotbar) {
                doSort(mc, container, containerId, playerHotbarSlots, config.sortMode);
            }
        }
    }
    
    private static void doSort(class_310 mc, class_1703 container, int containerId, 
                                List<Integer> slotIndices, int sortMode) {
        if (slotIndices.isEmpty()) {
            return;
        }
        
        int n = slotIndices.size();
        
        List<class_1799> currentItems = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            currentItems.add(container.method_7611(slotIndices.get(i)).method_7677().method_7972());
        }
        
        mergeItems(mc, container, containerId, slotIndices, currentItems);
        
        currentItems.clear();
        for (int i = 0; i < n; i++) {
            currentItems.add(container.method_7611(slotIndices.get(i)).method_7677().method_7972());
        }
        
        List<class_1799> targetItems = buildTargetItems(currentItems, sortMode);
        
        boolean[] done = new boolean[n];
        
        for (int targetIdx = 0; targetIdx < n; targetIdx++) {
            if (done[targetIdx]) continue;
            
            class_1799 target = targetItems.get(targetIdx);
            
            if (isAlreadyCorrect(currentItems, targetItems, targetIdx)) {
                done[targetIdx] = true;
                continue;
            }
            
            if (target.method_7960()) {
                class_1799 current = currentItems.get(targetIdx);
                if (!current.method_7960()) {
                    int emptyIdx = findEmptySlot(currentItems, done, targetIdx);
                    if (emptyIdx != -1) {
                        moveItem(mc, containerId, slotIndices, currentItems, targetIdx, emptyIdx);
                    }
                }
                done[targetIdx] = true;
                continue;
            }
            
            int sourceIdx = findSourceSlot(currentItems, target, done, targetIdx);
            if (sourceIdx == -1) {
                done[targetIdx] = true;
                continue;
            }
            
            class_1799 atTarget = currentItems.get(targetIdx);
            
            if (atTarget.method_7960()) {
                moveItem(mc, containerId, slotIndices, currentItems, sourceIdx, targetIdx);
                done[targetIdx] = true;
            } else {
                int emptyIdx = findEmptySlot(currentItems, done, targetIdx);
                if (emptyIdx != -1) {
                    moveItem(mc, containerId, slotIndices, currentItems, targetIdx, emptyIdx);
                    moveItem(mc, containerId, slotIndices, currentItems, sourceIdx, targetIdx);
                    done[targetIdx] = true;
                    done[emptyIdx] = false;
                } else {
                    swapItems(mc, containerId, slotIndices, currentItems, targetIdx, sourceIdx);
                    done[targetIdx] = true;
                    done[sourceIdx] = false;
                }
            }
        }
    }
    
    private static void mergeItems(class_310 mc, class_1703 container, int containerId,
                                    List<Integer> slotIndices, List<class_1799> items) {
        int n = slotIndices.size();
        
        for (int i = 0; i < n; i++) {
            class_1799 stackI = items.get(i);
            if (stackI.method_7960()) continue;
            
            int maxStack = stackI.method_7914();
            if (stackI.method_7947() >= maxStack) continue;
            
            for (int j = i + 1; j < n; j++) {
                class_1799 stackJ = items.get(j);
                if (stackJ.method_7960()) continue;
                
                if (!class_1799.method_31577(stackI, stackJ)) continue;
                
                int spaceInI = maxStack - stackI.method_7947();
                int toMove = Math.min(spaceInI, stackJ.method_7947());
                
                if (toMove > 0) {
                    mergeStacks(mc, containerId, slotIndices, items, j, i, toMove);
                    stackI = items.get(i);
                    if (stackI.method_7947() >= maxStack) break;
                }
            }
        }
    }
    
    private static void mergeStacks(class_310 mc, int containerId, List<Integer> slotIndices,
                                     List<class_1799> items, int fromIdx, int toIdx, int amount) {
        int fromSlot = slotIndices.get(fromIdx);
        int toSlot = slotIndices.get(toIdx);
        
        clickSlot(mc, containerId, fromSlot, 0, class_1713.field_7790);
        clickSlot(mc, containerId, toSlot, 0, class_1713.field_7790);
        clickSlot(mc, containerId, fromSlot, 0, class_1713.field_7790);
        
        class_1799 fromStack = items.get(fromIdx);
        class_1799 toStack = items.get(toIdx);
        
        int actualMoved = Math.min(amount, fromStack.method_7947());
        toStack.method_7933(actualMoved);
        fromStack.method_7934(actualMoved);
        
        if (fromStack.method_7960()) {
            items.set(fromIdx, class_1799.field_8037);
        }
    }
    
    private static boolean isAlreadyCorrect(List<class_1799> current, List<class_1799> target, int idx) {
        class_1799 currentStack = current.get(idx);
        class_1799 targetStack = target.get(idx);
        
        if (currentStack.method_7960() && targetStack.method_7960()) return true;
        if (currentStack.method_7960() || targetStack.method_7960()) return false;
        
        return class_1799.method_31577(currentStack, targetStack) && currentStack.method_7947() == targetStack.method_7947();
    }
    
    private static int findEmptySlot(List<class_1799> items, boolean[] done, int excludeIdx) {
        for (int i = excludeIdx + 1; i < items.size(); i++) {
            if (!done[i] && items.get(i).method_7960()) {
                return i;
            }
        }
        for (int i = 0; i < excludeIdx; i++) {
            if (!done[i] && items.get(i).method_7960()) {
                return i;
            }
        }
        for (int i = 0; i < items.size(); i++) {
            if (i != excludeIdx && items.get(i).method_7960()) {
                return i;
            }
        }
        return -1;
    }
    
    private static int findSourceSlot(List<class_1799> items, class_1799 target, boolean[] done, int excludeIdx) {
        for (int i = 0; i < items.size(); i++) {
            if (i == excludeIdx || done[i]) continue;
            
            class_1799 src = items.get(i);
            if (!src.method_7960() && class_1799.method_31577(src, target) && src.method_7947() == target.method_7947()) {
                return i;
            }
        }
        
        for (int i = 0; i < items.size(); i++) {
            if (i == excludeIdx || done[i]) continue;
            
            class_1799 src = items.get(i);
            if (!src.method_7960() && class_1799.method_31577(src, target)) {
                return i;
            }
        }
        
        return -1;
    }
    
    private static void moveItem(class_310 mc, int containerId, List<Integer> slotIndices, 
                                  List<class_1799> items, int fromIdx, int toIdx) {
        int fromSlot = slotIndices.get(fromIdx);
        int toSlot = slotIndices.get(toIdx);
        
        clickSlot(mc, containerId, fromSlot, 0, class_1713.field_7790);
        clickSlot(mc, containerId, toSlot, 0, class_1713.field_7790);
        
        class_1799 temp = items.get(fromIdx);
        items.set(fromIdx, items.get(toIdx));
        items.set(toIdx, temp);
    }
    
    private static void swapItems(class_310 mc, int containerId, List<Integer> slotIndices, 
                                   List<class_1799> items, int idx1, int idx2) {
        int slot1 = slotIndices.get(idx1);
        int slot2 = slotIndices.get(idx2);
        
        clickSlot(mc, containerId, slot1, 0, class_1713.field_7790);
        clickSlot(mc, containerId, slot2, 0, class_1713.field_7790);
        clickSlot(mc, containerId, slot1, 0, class_1713.field_7790);
        
        class_1799 temp = items.get(idx1);
        items.set(idx1, items.get(idx2));
        items.set(idx2, temp);
    }
    
    private static List<class_1799> buildTargetItems(List<class_1799> currentItems, int sortMode) {
        Map<ItemKey, MergedItem> mergedMap = new HashMap<>();
        
        for (class_1799 stack : currentItems) {
            if (!stack.method_7960()) {
                ItemKey key = new ItemKey(stack);
                MergedItem merged = mergedMap.computeIfAbsent(key, k -> new MergedItem(stack.method_7972()));
                merged.totalCount += stack.method_7947();
            }
        }
        
        List<class_1799> result = new ArrayList<>();
        
        for (MergedItem merged : mergedMap.values()) {
            int remaining = merged.totalCount;
            int maxStack = merged.template.method_7914();
            
            while (remaining > 0) {
                int count = Math.min(remaining, maxStack);
                class_1799 newStack = merged.template.method_7972();
                newStack.method_7939(count);
                result.add(newStack);
                remaining -= count;
            }
        }
        
        result.sort(getComparator(sortMode));
        
        while (result.size() < currentItems.size()) {
            result.add(class_1799.field_8037);
        }
        
        return result;
    }
    
    private static class ItemKey {
        private final class_2960 itemId;
        private final int tagHash;
        
        public ItemKey(class_1799 stack) {
            this.itemId = class_7923.field_41178.method_10221(stack.method_7909());
            this.tagHash = stack.method_7985() ? stack.method_7969().hashCode() : 0;
        }
        
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ItemKey itemKey = (ItemKey) o;
            return tagHash == itemKey.tagHash && itemId.equals(itemKey.itemId);
        }
        
        @Override
        public int hashCode() {
            return 31 * itemId.hashCode() + tagHash;
        }
    }
    
    private static class MergedItem {
        final class_1799 template;
        int totalCount;
        
        MergedItem(class_1799 template) {
            this.template = template;
            this.totalCount = 0;
        }
    }
    
    private static Comparator<class_1799> getComparator(int sortMode) {
        return switch (sortMode) {
            case 1 -> new DisplayNameComparator();
            case 2 -> new ItemIdComparator();
            default -> new IPNRuleComparator();
        };
    }
    
    private static class IPNRuleComparator implements Comparator<class_1799> {
        @Override
        public int compare(class_1799 a, class_1799 b) {
            if (a.method_7960() && b.method_7960()) return 0;
            if (a.method_7960()) return 1;
            if (b.method_7960()) return -1;
            
            int result = compareCreativeMenuOrder(a, b);
            if (result != 0) return result;
            
            result = compareCustomName(a, b);
            if (result != 0) return result;
            
            result = compareEnchantmentScore(a, b);
            if (result != 0) return result;
            
            result = compareDurability(a, b);
            if (result != 0) return result;
            
            result = compareDisplayName(a, b);
            if (result != 0) return result;
            
            result = comparePotionEffects(a, b);
            if (result != 0) return result;
            
            result = compareNBT(a, b);
            if (result != 0) return result;
            
            return Integer.compare(b.method_7947(), a.method_7947());
        }
        
        private int compareCreativeMenuOrder(class_1799 a, class_1799 b) {
            int indexA = getSearchTabIndex(a);
            int indexB = getSearchTabIndex(b);
            return Integer.compare(indexA, indexB);
        }
        
        private int getSearchTabIndex(class_1799 stack) {
            int idx = 0;
            for (class_1761 tab : class_7706.method_47341()) {
                if (tab.method_47312() == class_1761.class_7916.field_41052) {
                    if (tab.method_45412(stack)) {
                        return idx;
                    }
                    idx++;
                }
            }
            return Integer.MAX_VALUE;
        }
        
        private int compareCustomName(class_1799 a, class_1799 b) {
            boolean hasCustomA = a.method_7938();
            boolean hasCustomB = b.method_7938();
            if (hasCustomA && !hasCustomB) return -1;
            if (!hasCustomA && hasCustomB) return 1;
            return 0;
        }
        
        private int compareEnchantmentScore(class_1799 a, class_1799 b) {
            int scoreA = computeEnchantmentScore(a);
            int scoreB = computeEnchantmentScore(b);
            return Integer.compare(scoreB, scoreA);
        }
        
        private int computeEnchantmentScore(class_1799 stack) {
            if (!stack.method_7985()) return 0;
            class_2487 tag = stack.method_7969();
            if (tag == null || !tag.method_10573("Enchantments", class_2520.field_33259)) return 0;
            
            int score = 0;
            class_2499 enchantments = tag.method_10554("Enchantments", class_2520.field_33260);
            for (int i = 0; i < enchantments.size(); i++) {
                class_2487 ench = enchantments.method_10602(i);
                score += ench.method_10550("lvl");
            }
            return score;
        }
        
        private int compareDurability(class_1799 a, class_1799 b) {
            boolean damageableA = a.method_7963();
            boolean damageableB = b.method_7963();
            
            if (!damageableA && !damageableB) return 0;
            if (damageableA && !damageableB) return -1;
            if (!damageableA && damageableB) return 1;
            
            int durabilityA = a.method_7936() - a.method_7919();
            int durabilityB = b.method_7936() - b.method_7919();
            return Integer.compare(durabilityB, durabilityA);
        }
        
        private int compareDisplayName(class_1799 a, class_1799 b) {
            String nameA = a.method_7954().getString();
            String nameB = b.method_7954().getString();
            return nameA.compareToIgnoreCase(nameB);
        }
        
        private int comparePotionEffects(class_1799 a, class_1799 b) {
            boolean isPotionA = a.method_7909() instanceof net.minecraft.class_1812;
            boolean isPotionB = b.method_7909() instanceof net.minecraft.class_1812;
            
            if (isPotionA && isPotionB) {
                String potionA = class_1844.method_8063(a).method_8051("");
                String potionB = class_1844.method_8063(b).method_8051("");
                return potionA.compareTo(potionB);
            }
            if (isPotionA) return -1;
            if (isPotionB) return 1;
            return 0;
        }
        
        private int compareNBT(class_1799 a, class_1799 b) {
            boolean hasNbtA = a.method_7985();
            boolean hasNbtB = b.method_7985();
            
            if (hasNbtA && hasNbtB) {
                return a.method_7969().toString().compareTo(b.method_7969().toString());
            }
            if (hasNbtA) return -1;
            if (hasNbtB) return 1;
            return 0;
        }
    }
    
    private static class DisplayNameComparator implements Comparator<class_1799> {
        @Override
        public int compare(class_1799 a, class_1799 b) {
            if (a.method_7960() && b.method_7960()) return 0;
            if (a.method_7960()) return 1;
            if (b.method_7960()) return -1;
            
            int result = compareCustomName(a, b);
            if (result != 0) return result;
            
            String nameA = a.method_7954().getString();
            String nameB = b.method_7954().getString();
            result = nameA.compareToIgnoreCase(nameB);
            if (result != 0) return result;
            
            return Integer.compare(b.method_7947(), a.method_7947());
        }
        
        private int compareCustomName(class_1799 a, class_1799 b) {
            boolean hasCustomA = a.method_7938();
            boolean hasCustomB = b.method_7938();
            if (hasCustomA && !hasCustomB) return -1;
            if (!hasCustomA && hasCustomB) return 1;
            return 0;
        }
    }
    
    private static class ItemIdComparator implements Comparator<class_1799> {
        @Override
        public int compare(class_1799 a, class_1799 b) {
            if (a.method_7960() && b.method_7960()) return 0;
            if (a.method_7960()) return 1;
            if (b.method_7960()) return -1;
            
            class_2960 idA = class_7923.field_41178.method_10221(a.method_7909());
            class_2960 idB = class_7923.field_41178.method_10221(b.method_7909());
            
            int result = idA.method_12836().compareTo(idB.method_12836());
            if (result != 0) return result;
            
            result = idA.method_12832().compareTo(idB.method_12832());
            if (result != 0) return result;
            
            return Integer.compare(b.method_7947(), a.method_7947());
        }
    }
    
    public static boolean isSorting() {
        return sorting;
    }
    
    public static void reset() {
        sorting = false;
    }
}
