package org.alku.catalyst.client.waypoint;

import java.util.Objects;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;

public class Waypoint {
    private final String id;
    private final String name;
    private final class_2338 pos;
    private final class_5321<class_1937> dimension;
    private final int color;
    
    public Waypoint(String name, class_2338 pos, class_5321<class_1937> dimension, int color) {
        this.id = java.util.UUID.randomUUID().toString();
        this.name = name;
        this.pos = pos;
        this.dimension = dimension;
        this.color = color;
    }
    
    public Waypoint(String id, String name, class_2338 pos, class_5321<class_1937> dimension, int color) {
        this.id = id;
        this.name = name;
        this.pos = pos;
        this.dimension = dimension;
        this.color = color;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public class_2338 getPos() {
        return pos;
    }
    
    public int getX() {
        return pos.method_10263();
    }
    
    public int getY() {
        return pos.method_10264();
    }
    
    public int getZ() {
        return pos.method_10260();
    }
    
    public class_5321<class_1937> getDimension() {
        return dimension;
    }
    
    public int getColor() {
        return color;
    }
    
    public String getInitial() {
        return getInitial(name);
    }
    
    public static String getInitial(String name) {
        if (name == null || name.isEmpty()) {
            return "?";
        }
        return String.valueOf(name.charAt(0)).toUpperCase();
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Waypoint waypoint = (Waypoint) o;
        return Objects.equals(id, waypoint.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
