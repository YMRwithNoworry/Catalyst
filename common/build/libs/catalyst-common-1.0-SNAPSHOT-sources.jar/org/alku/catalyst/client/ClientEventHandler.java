package org.alku.catalyst.client;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.client.ClientRawInputEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.alku.catalyst.client.feature.*;
import org.alku.catalyst.client.gui.CatalystConfigScreen;
import org.alku.catalyst.client.gui.WaypointScreen;
import org.alku.catalyst.client.waypoint.Waypoint;
import org.alku.catalyst.client.waypoint.WaypointManager;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.glfw.GLFW;

public class ClientEventHandler {
    
    public static void init() {
        CatalystKeys.register();
        
        ClientTickEvent.CLIENT_PRE.register(ClientEventHandler::onClientTick);
        ClientRawInputEvent.MOUSE_CLICKED_PRE.register(ClientEventHandler::onMouseClicked);
    }
    
    private static EventResult onMouseClicked(class_310 mc, int button, int action, int mods) {
        if (button == 0 && action == 1) {
            AutoWeapon.checkAndSwitch(mc);
            AutoTool.checkAndSwitch(mc);
        }
        return EventResult.pass();
    }
    
    private static void onClientTick(class_310 mc) {
        handleKeyInputs(mc);
        
        AutoSprint.tick(mc);
        AutoSwim.tick(mc);
        GammaOverride.tick(mc);
        AutoTool.tick(mc);
        AutoWeapon.tick(mc);
        AutoDoor.tick(mc);
        AutoWaterBucket.tick(mc);
    }
    
    private static void handleKeyInputs(class_310 mc) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (CatalystKeys.OPEN_CONFIG.method_1436()) {
            mc.method_1507(new CatalystConfigScreen(null));
        }
        
        if (CatalystKeys.TOGGLE_AUTO_SPRINT.method_1436()) {
            config.autoSprintEnabled = !config.autoSprintEnabled;
            config.save();
            sendFeedback(mc, "auto_sprint", config.autoSprintEnabled);
        }
        
        if (CatalystKeys.TOGGLE_AUTO_SWIM.method_1436()) {
            config.autoSwimEnabled = !config.autoSwimEnabled;
            config.save();
            sendFeedback(mc, "auto_swim", config.autoSwimEnabled);
        }
        
        if (CatalystKeys.TOGGLE_GAMMA_OVERRIDE.method_1436()) {
            config.gammaOverrideEnabled = !config.gammaOverrideEnabled;
            config.save();
            if (!config.gammaOverrideEnabled) {
                GammaOverride.onDisable(mc);
            }
            sendFeedback(mc, "gamma_override", config.gammaOverrideEnabled);
        }
        
        if (CatalystKeys.TOGGLE_AUTO_TOOL.method_1436()) {
            config.autoToolEnabled = !config.autoToolEnabled;
            config.save();
            sendFeedback(mc, "auto_tool", config.autoToolEnabled);
        }
        
        if (CatalystKeys.TOGGLE_AUTO_WEAPON.method_1436()) {
            config.autoWeaponEnabled = !config.autoWeaponEnabled;
            config.save();
            sendFeedback(mc, "auto_weapon", config.autoWeaponEnabled);
        }
        
        if (CatalystKeys.SORT_INVENTORY.method_1436()) {
            InventorySorter.sortCurrentContainer(mc);
        }
    }
    
    private static void sendFeedback(class_310 mc, String feature, boolean enabled) {
        class_746 player = mc.field_1724;
        if (player == null) {
            return;
        }
        
        String status = enabled ? "enabled" : "disabled";
        String message = String.format("§6[Catalyst] §f%s §%s", 
            class_2561.method_43471("catalyst.feature." + feature).getString(),
            enabled ? "a" + status : "c" + status);
        player.method_7353(class_2561.method_43470(message), true);
    }
}
