package org.alku.catalyst.client;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.client.ClientRawInputEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.alku.catalyst.client.feature.*;
import org.alku.catalyst.client.gui.CatalystConfigScreen;
import org.alku.catalyst.client.gui.KeybindManager;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.glfw.GLFW;

public class ClientEventHandler {
    private static int[] prevKeyStates = new int[9];
    
    public static void init() {
        CatalystKeys.register();
        
        for (int i = 0; i < prevKeyStates.length; i++) {
            prevKeyStates[i] = GLFW.GLFW_RELEASE;
        }
        
        ClientTickEvent.CLIENT_PRE.register(ClientEventHandler::onClientTick);
        ClientRawInputEvent.MOUSE_CLICKED_PRE.register(ClientEventHandler::onMouseClicked);
    }
    
    private static EventResult onMouseClicked(class_310 mc, int button, int action, int mods) {
        if (button == 0 && action == 1) {
            AutoWeapon.checkAndSwitch(mc);
            AutoTool.checkAndSwitch(mc);
        }
        return EventResult.pass();
    }
    
    private static void onClientTick(class_310 mc) {
        handleKeyInputs(mc);
        
        AutoSprint.tick(mc);
        AutoSwim.tick(mc);
        GammaOverride.tick(mc);
        AutoTool.tick(mc);
        AutoWeapon.tick(mc);
        AutoDoor.tick(mc);
        AutoWaterBucket.tick(mc);
    }
    
    private static void handleKeyInputs(class_310 mc) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (checkKeybind(mc, "open_config", 0)) {
            mc.method_1507(new CatalystConfigScreen(null));
        }
        
        if (checkKeybind(mc, "toggle_auto_sprint", 1)) {
            config.autoSprintEnabled = !config.autoSprintEnabled;
            config.save();
            sendFeedback(mc, "auto_sprint", config.autoSprintEnabled);
        }
        
        if (checkKeybind(mc, "toggle_auto_swim", 2)) {
            config.autoSwimEnabled = !config.autoSwimEnabled;
            config.save();
            sendFeedback(mc, "auto_swim", config.autoSwimEnabled);
        }
        
        if (checkKeybind(mc, "toggle_gamma_override", 3)) {
            config.gammaOverrideEnabled = !config.gammaOverrideEnabled;
            config.save();
            if (!config.gammaOverrideEnabled) {
                GammaOverride.onDisable(mc);
            }
            sendFeedback(mc, "gamma_override", config.gammaOverrideEnabled);
        }
        
        if (checkKeybind(mc, "toggle_auto_tool", 4)) {
            config.autoToolEnabled = !config.autoToolEnabled;
            config.save();
            sendFeedback(mc, "auto_tool", config.autoToolEnabled);
        }
        
        if (checkKeybind(mc, "toggle_auto_weapon", 5)) {
            config.autoWeaponEnabled = !config.autoWeaponEnabled;
            config.save();
            sendFeedback(mc, "auto_weapon", config.autoWeaponEnabled);
        }
        
        if (checkKeybind(mc, "toggle_auto_door", 6)) {
            config.autoDoorEnabled = !config.autoDoorEnabled;
            config.save();
            sendFeedback(mc, "auto_door", config.autoDoorEnabled);
        }
        
        if (checkKeybind(mc, "toggle_auto_water_bucket", 7)) {
            config.autoWaterBucketEnabled = !config.autoWaterBucketEnabled;
            config.save();
            sendFeedback(mc, "auto_water_bucket", config.autoWaterBucketEnabled);
        }
        
        if (checkKeybind(mc, "toggle_chams", 8)) {
            config.chamsEnabled = !config.chamsEnabled;
            config.save();
            sendFeedback(mc, "chams", config.chamsEnabled);
        }
    }
    
    private static boolean checkKeybind(class_310 mc, String keyName, int index) {
        int keyCode = KeybindManager.getKey(keyName);
        if (keyCode == GLFW.GLFW_KEY_UNKNOWN) {
            return false;
        }
        
        long window = mc.method_22683().method_4490();
        int currentState = GLFW.glfwGetKey(window, keyCode);
        
        boolean pressed = (currentState == GLFW.GLFW_PRESS) && (prevKeyStates[index] == GLFW.GLFW_RELEASE);
        prevKeyStates[index] = currentState;
        
        return pressed;
    }
    
    private static void sendFeedback(class_310 mc, String feature, boolean enabled) {
        class_746 player = mc.field_1724;
        if (player == null) {
            return;
        }
        
        String status = enabled ? "enabled" : "disabled";
        String message = String.format("§6[Catalyst] §f%s §%s", 
            class_2561.method_43471("catalyst.feature." + feature).getString(),
            enabled ? "a" + status : "c" + status);
        player.method_7353(class_2561.method_43470(message), true);
    }
}
