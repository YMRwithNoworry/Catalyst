package org.alku.catalyst.client.feature;

import org.alku.catalyst.config.CatalystConfig;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1263;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class InventorySorter {
    private static boolean isSorting = false;
    private static final List<Runnable> pendingActions = new ArrayList<>();
    private static int actionIndex = 0;
    private static long lastActionTime = 0;
    private static final int ACTION_DELAY_MS = 50;
    private static int currentContainerId = -1;
    
    public static void sortCurrentContainer(class_310 mc) {
        if (!CatalystConfig.getInstance().inventorySorterEnabled || isSorting) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1761 == null) {
            return;
        }
        
        class_1703 container = player.field_7512;
        if (container == null) {
            return;
        }
        
        isSorting = true;
        pendingActions.clear();
        actionIndex = 0;
        currentContainerId = container.field_7763;
        
        if (container instanceof class_1723) {
            sortPlayerInventory(mc, player, container);
        } else {
            sortOpenContainer(mc, player, container);
        }
        
        if (pendingActions.isEmpty()) {
            isSorting = false;
        }
    }
    
    public static void tick(class_310 mc) {
        if (!isSorting || pendingActions.isEmpty()) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null || player.field_7512 == null || 
            player.field_7512.field_7763 != currentContainerId) {
            reset();
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastActionTime < ACTION_DELAY_MS) {
            return;
        }
        
        if (actionIndex < pendingActions.size()) {
            pendingActions.get(actionIndex).run();
            actionIndex++;
            lastActionTime = currentTime;
        } else {
            reset();
        }
    }
    
    private static void clickSlot(class_310 mc, int slotIndex, int button, class_1713 clickType) {
        if (mc.field_1724 != null && mc.field_1761 != null) {
            mc.field_1761.method_2906(currentContainerId, slotIndex, button, clickType, mc.field_1724);
        }
    }
    
    public static void sortPlayerInventory(class_310 mc, class_746 player, class_1703 container) {
        List<Integer> inventorySlots = new ArrayList<>();
        List<Integer> hotbarSlots = new ArrayList<>();
        
        for (class_1735 slot : container.field_7761) {
            if (slot.field_7871 == player.method_31548()) {
                int index = slot.field_7874;
                if (index >= 0 && index < 9) {
                    hotbarSlots.add(slot.field_7874);
                } else if (index >= 9 && index < 36) {
                    inventorySlots.add(slot.field_7874);
                }
            }
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (config.sortHotbar) {
            planSortSlots(mc, container, hotbarSlots, config.sortMode);
        }
        
        planSortSlots(mc, container, inventorySlots, config.sortMode);
    }
    
    public static void sortOpenContainer(class_310 mc, class_746 player, class_1703 container) {
        List<Integer> containerSlots = new ArrayList<>();
        List<Integer> playerInvSlots = new ArrayList<>();
        List<Integer> playerHotbarSlots = new ArrayList<>();
        
        class_1263 playerInventory = player.method_31548();
        
        for (class_1735 slot : container.field_7761) {
            if (slot.field_7871 == playerInventory) {
                int index = slot.field_7874;
                if (index >= 0 && index < 9) {
                    playerHotbarSlots.add(slot.field_7874);
                } else if (index >= 9 && index < 36) {
                    playerInvSlots.add(slot.field_7874);
                }
            } else if (slot.field_7871 != null && slot.field_7871 != playerInventory) {
                containerSlots.add(slot.field_7874);
            }
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        planSortSlots(mc, container, containerSlots, config.sortMode);
        
        if (config.sortPlayerInventoryInContainer) {
            planSortSlots(mc, container, playerInvSlots, config.sortMode);
            if (config.sortHotbar) {
                planSortSlots(mc, container, playerHotbarSlots, config.sortMode);
            }
        }
    }
    
    private static void planSortSlots(class_310 mc, class_1703 container, List<Integer> slotIndices, int sortMode) {
        if (slotIndices.isEmpty()) {
            return;
        }
        
        List<class_1799> items = new ArrayList<>();
        for (int slotIndex : slotIndices) {
            class_1735 slot = container.method_7611(slotIndex);
            if (slot != null && !slot.method_7677().method_7960()) {
                items.add(slot.method_7677().method_7972());
            }
        }
        
        if (items.isEmpty()) {
            return;
        }
        
        List<class_1799> merged = mergeStacks(items);
        Comparator<class_1799> comparator = getComparator(sortMode);
        merged.sort(comparator);
        
        Map<Integer, class_1799> targetLayout = new HashMap<>();
        for (int i = 0; i < slotIndices.size(); i++) {
            if (i < merged.size()) {
                targetLayout.put(slotIndices.get(i), merged.get(i));
            } else {
                targetLayout.put(slotIndices.get(i), class_1799.field_8037);
            }
        }
        
        planMoveActions(mc, container, slotIndices, targetLayout);
    }
    
    private static void planMoveActions(class_310 mc, class_1703 container, List<Integer> slotIndices, Map<Integer, class_1799> targetLayout) {
        Map<Integer, class_1799> currentLayout = new HashMap<>();
        for (int slotIndex : slotIndices) {
            class_1735 slot = container.method_7611(slotIndex);
            if (slot != null) {
                currentLayout.put(slotIndex, slot.method_7677().method_7972());
            }
        }
        
        List<int[]> moves = new ArrayList<>();
        
        for (int targetSlot : slotIndices) {
            class_1799 targetStack = targetLayout.get(targetSlot);
            class_1799 currentStack = currentLayout.get(targetSlot);
            
            if (class_1799.method_31577(targetStack, currentStack) && 
                targetStack.method_7947() == currentStack.method_7947()) {
                continue;
            }
            
            if (!targetStack.method_7960() && !class_1799.method_31577(targetStack, currentStack)) {
                for (int sourceSlot : slotIndices) {
                    if (sourceSlot == targetSlot) continue;
                    
                    class_1799 sourceStack = currentLayout.get(sourceSlot);
                    if (!sourceStack.method_7960() && class_1799.method_31577(sourceStack, targetStack)) {
                        moves.add(new int[]{sourceSlot, targetSlot});
                        
                        int transferCount = Math.min(sourceStack.method_7947(), 
                            targetStack.method_7914() - currentStack.method_7947());
                        
                        if (currentStack.method_7960()) {
                            currentLayout.put(targetSlot, sourceStack.method_7972());
                        } else {
                            currentLayout.get(targetSlot).method_7933(transferCount);
                        }
                        currentLayout.get(sourceSlot).method_7934(transferCount);
                        
                        if (currentLayout.get(sourceSlot).method_7960()) {
                            currentLayout.put(sourceSlot, class_1799.field_8037);
                        }
                        break;
                    }
                }
            }
        }
        
        for (int[] move : moves) {
            int fromSlot = move[0];
            int toSlot = move[1];
            
            pendingActions.add(() -> {
                clickSlot(mc, fromSlot, 0, class_1713.field_7790);
            });
            pendingActions.add(() -> {
                clickSlot(mc, toSlot, 0, class_1713.field_7790);
            });
            pendingActions.add(() -> {
                if (mc.field_1724 != null) {
                    class_1703 c = mc.field_1724.field_7512;
                    if (c != null && !c.method_34255().method_7960()) {
                        clickSlot(mc, fromSlot, 0, class_1713.field_7790);
                    }
                }
            });
        }
    }
    
    private static List<class_1799> mergeStacks(List<class_1799> items) {
        List<class_1799> merged = new ArrayList<>();
        
        for (class_1799 stack : items) {
            boolean merged_flag = false;
            
            for (class_1799 existing : merged) {
                if (class_1799.method_31577(stack, existing) && existing.method_7947() < existing.method_7914()) {
                    int space = existing.method_7914() - existing.method_7947();
                    int toAdd = Math.min(space, stack.method_7947());
                    existing.method_7933(toAdd);
                    stack.method_7934(toAdd);
                    
                    if (stack.method_7960()) {
                        merged_flag = true;
                        break;
                    }
                }
            }
            
            if (!merged_flag && !stack.method_7960()) {
                merged.add(stack);
            }
        }
        
        return merged;
    }
    
    private static Comparator<class_1799> getComparator(int sortMode) {
        return switch (sortMode) {
            case 1 -> Comparator.comparing(stack -> stack.method_7954().getString());
            case 2 -> Comparator.comparingInt(stack -> net.minecraft.class_7923.field_41178.method_10206(stack.method_7909()));
            default -> (stack1, stack2) -> {
                String category1 = getItemCategory(stack1);
                String category2 = getItemCategory(stack2);
                
                if (!category1.equals(category2)) {
                    return category1.compareTo(category2);
                }
                
                return stack1.method_7954().getString().compareTo(stack2.method_7954().getString());
            };
        };
    }
    
    private static String getItemCategory(class_1799 stack) {
        var item = stack.method_7909();
        
        if (item instanceof net.minecraft.class_1747) {
            return "1_Blocks";
        }
        if (item instanceof net.minecraft.class_1829 || 
            item instanceof net.minecraft.class_1743 ||
            item instanceof net.minecraft.class_1810 ||
            item instanceof net.minecraft.class_1821 ||
            item instanceof net.minecraft.class_1794 ||
            item instanceof net.minecraft.class_1753 ||
            item instanceof net.minecraft.class_1764 ||
            item instanceof net.minecraft.class_1835) {
            return "2_Weapons_Tools";
        }
        if (item instanceof net.minecraft.class_1738) {
            return "3_Armor";
        }
        if (item.method_19263()) {
            return "4_Food";
        }
        if (stack.method_31579() > 0) {
            return "5_Durability";
        }
        return "6_Other";
    }
    
    public static boolean isSorting() {
        return isSorting;
    }
    
    public static void reset() {
        isSorting = false;
        pendingActions.clear();
        actionIndex = 0;
        currentContainerId = -1;
    }
}
