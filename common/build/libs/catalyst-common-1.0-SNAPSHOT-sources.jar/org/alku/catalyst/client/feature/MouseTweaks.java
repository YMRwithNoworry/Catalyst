package org.alku.catalyst.client.feature;

import dev.architectury.event.EventResult;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;

public class MouseTweaks {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("MouseTweaks");
    
    private static boolean mouseLeftDown = false;
    private static boolean mouseRightDown = false;
    private static int lastMouseX = -1;
    private static int lastMouseY = -1;
    private static class_1735 lastHoveredSlot = null;
    private static boolean isDragging = false;
    private static int dragStartX = -1;
    private static int dragStartY = -1;
    private static int dragButton = -1;
    
    private static Map<class_1735, Integer> rmbSlotPassCounts = new HashMap<>();
    private static class_1799 rmbDragItem = class_1799.field_8037;
    
    private static class_1799 lmbDragItem = class_1799.field_8037;
    private static boolean lmbShiftDragMode = false;
    
    public static void init() {
    }
    
    public static void tick(class_310 mc) {
        if (mc.field_1755 instanceof class_465) {
            double mouseX = mc.field_1729.method_1603();
            double mouseY = mc.field_1729.method_1604();
            
            double guiScale = mc.method_22683().method_4495();
            int scaledMouseX = (int) (mouseX / guiScale);
            int scaledMouseY = (int) (mouseY / guiScale);
            
            onMouseMove(mc, scaledMouseX, scaledMouseY);
        }
    }
    
    private static class_1735 getHoveredSlot(class_465<?> screen, int mouseX, int mouseY) {
        if (screen == null) {
            return null;
        }
        
        try {
            Field hoveredSlotField = class_465.class.getDeclaredField("hoveredSlot");
            hoveredSlotField.setAccessible(true);
            class_1735 hoveredSlot = (class_1735) hoveredSlotField.get(screen);
            return hoveredSlot;
        } catch (Exception e) {
            try {
                Field leftPosField = class_465.class.getDeclaredField("leftPos");
                Field topPosField = class_465.class.getDeclaredField("topPos");
                leftPosField.setAccessible(true);
                topPosField.setAccessible(true);
                
                int leftPos = leftPosField.getInt(screen);
                int topPos = topPosField.getInt(screen);
                
                int relX = mouseX - leftPos;
                int relY = mouseY - topPos;
                
                for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                    class_1735 slot = screen.method_17577().method_7611(i);
                    if (relX >= slot.field_7873 && relX < slot.field_7873 + 16 && relY >= slot.field_7872 && relY < slot.field_7872 + 16) {
                        return slot;
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        return null;
    }
    
    private static boolean isShiftKeyDown(class_310 mc) {
        return mc.field_1690.field_1832.method_1434() || 
               GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS ||
               GLFW.glfwGetKey(mc.method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }
    
    public static EventResult onMouseClicked(class_310 mc, int button, int action, int mods) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        if (action == 1) {
            if (button == 0) {
                mouseLeftDown = true;
                dragButton = 0;
                dragStartX = lastMouseX;
                dragStartY = lastMouseY;
                
                if (config.lmbTweakWithItem || config.lmbTweakWithoutItem) {
                    return handleLeftClickStart(mc, button, action, mods);
                }
            } else if (button == 1) {
                mouseRightDown = true;
                dragButton = 1;
                dragStartX = lastMouseX;
                dragStartY = lastMouseY;
                
                if (config.rmbTweak) {
                    return handleRightClickStart(mc, button, action, mods);
                }
            }
        } else if (action == 0) {
            if (button == 0) {
                mouseLeftDown = false;
                if (isDragging && dragButton == 0) {
                    isDragging = false;
                    return handleLeftClickEnd(mc, button, action, mods);
                }
            } else if (button == 1) {
                mouseRightDown = false;
                if (isDragging && dragButton == 1) {
                    isDragging = false;
                    return handleRightClickEnd(mc, button, action, mods);
                }
            }
        }
        
        return EventResult.pass();
    }
    
    public static EventResult onMouseScrolled(class_310 mc, double scrollDelta) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!config.wheelTweak || !(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        return handleWheelScroll(mc, scrollDelta);
    }
    
    public static void onMouseMove(class_310 mc, double mouseX, double mouseY) {
        int currentMouseX = (int) mouseX;
        int currentMouseY = (int) mouseY;
        
        if (!(mc.field_1755 instanceof class_465)) {
            lastMouseX = currentMouseX;
            lastMouseY = currentMouseY;
            return;
        }
        
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, currentMouseX, currentMouseY);
        
        if ((mouseLeftDown || mouseRightDown) && !isDragging) {
            int dx = Math.abs(currentMouseX - dragStartX);
            int dy = Math.abs(currentMouseY - dragStartY);
            
            if (dx > 3 || dy > 3) {
                isDragging = true;
                System.out.println("[MouseTweaks] Drag started - dragButton=" + dragButton + ", lmbShiftDragMode=" + lmbShiftDragMode);
            }
        }
        
        if (isDragging) {
            processAllSlotsAlongPath(mc, lastMouseX, lastMouseY, currentMouseX, currentMouseY, screen);
        }
        
        lastHoveredSlot = hoveredSlot;
        lastMouseX = currentMouseX;
        lastMouseY = currentMouseY;
    }
    
    private static void processAllSlotsAlongPath(class_310 mc, int x1, int y1, int x2, int y2, class_465<?> screen) {
        if (dragButton != 0) {
            return;
        }
        
        boolean shiftDown = isShiftKeyDown(mc);
        
        try {
            Field leftPosField = class_465.class.getDeclaredField("leftPos");
            Field topPosField = class_465.class.getDeclaredField("topPos");
            leftPosField.setAccessible(true);
            topPosField.setAccessible(true);
            
            int leftPos = leftPosField.getInt(screen);
            int topPos = topPosField.getInt(screen);
            
            int processedCount = 0;
            for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                class_1735 slot = screen.method_17577().method_7611(i);
                int slotScreenX = leftPos + slot.field_7873 + 8;
                int slotScreenY = topPos + slot.field_7872 + 8;
                
                double dist = pointToLineDistance(x1, y1, x2, y2, slotScreenX, slotScreenY);
                if (dist <= 12) {
                    System.out.println("[MouseTweaks] Slot " + i + " at (" + slotScreenX + "," + slotScreenY + ") mouse(" + x1 + "," + y1 + ")-(" + x2 + "," + y2 + ") dist=" + String.format("%.1f", dist));
                    processSlot(mc, slot, shiftDown);
                    processedCount++;
                }
            }
            if (processedCount > 0) {
                System.out.println("[MouseTweaks] Processed " + processedCount + " slots, mouse from(" + x1 + "," + y1 + ") to(" + x2 + "," + y2 + ")");
            }
        } catch (Exception e) {
            System.out.println("[MouseTweaks] ERROR in processAllSlotsAlongPath: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static double pointToLineDistance(int x1, int y1, int x2, int y2, int px, int py) {
        double lineLen = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (lineLen == 0) {
            return Math.sqrt((px - x1) * (px - x1) + (py - y1) * (py - y1));
        }
        
        double t = Math.max(0, Math.min(1, ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (lineLen * lineLen)));
        double nearestX = x1 + t * (x2 - x1);
        double nearestY = y1 + t * (y2 - y1);
        
        return Math.sqrt((px - nearestX) * (px - nearestX) + (py - nearestY) * (py - nearestY));
    }
    
    private static void processSlot(class_310 mc, class_1735 slot, boolean shiftDown) {
        System.out.println("[MouseTweaks] processSlot - lmbShiftDragMode=" + lmbShiftDragMode + ", shiftDown=" + shiftDown + ", slotIndex=" + slot.field_7874 + ", slotHasItem=" + !slot.method_7677().method_7960());
        
        if (lmbShiftDragMode) {
            if (shiftDown && !slot.method_7677().method_7960()) {
                System.out.println("[MouseTweaks] Performing shift click on slot " + slot.field_7874);
                performShiftClick(mc, slot);
            }
        } else if (!lmbDragItem.method_7960()) {
            class_1799 slotItem = slot.method_7677();
            if (!slotItem.method_7960() && class_1799.method_31577(lmbDragItem, slotItem)) {
                if (shiftDown) {
                    performShiftClick(mc, slot);
                } else {
                    performMerge(mc, slot);
                }
            }
        }
    }
    
    private static EventResult handleLeftClickStart(class_310 mc, int button, int action, int mods) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        boolean shiftDown = isShiftKeyDown(mc);
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        System.out.println("[MouseTweaks] Left click start - shiftDown=" + shiftDown + ", lmbTweakWithoutItem=" + config.lmbTweakWithoutItem);
        
        lmbShiftDragMode = false;
        lmbDragItem = class_1799.field_8037;
        
        if (shiftDown && config.lmbTweakWithoutItem) {
            lmbShiftDragMode = true;
            System.out.println("[MouseTweaks] Entering Shift drag mode");
            return EventResult.interruptDefault();
        }
        
        if (hoveredSlot != null && mc.field_1761 != null) {
            class_1703 menu = mc.field_1724.field_7512;
            int containerId = menu.field_7763;
            
            class_1799 carriedBefore = menu.method_34255();
            
            if (carriedBefore.method_7960()) {
                if (config.lmbTweakWithItem) {
                    mc.field_1761.method_2906(containerId, hoveredSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
                    lmbDragItem = menu.method_34255();
                    System.out.println("[MouseTweaks] Picked up item: " + !lmbDragItem.method_7960());
                } else {
                    return EventResult.pass();
                }
            } else {
                lmbDragItem = carriedBefore;
            }
        } else {
            lmbDragItem = mc.field_1724.field_7512.method_34255();
        }
        
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickStart(class_310 mc, int button, int action, int mods) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        if (hoveredSlot != null && mc.field_1761 != null) {
            class_1703 menu = mc.field_1724.field_7512;
            int containerId = menu.field_7763;
            
            class_1799 carriedBefore = menu.method_34255();
            
            mc.field_1761.method_2906(containerId, hoveredSlot.field_7874, 1, class_1713.field_7790, mc.field_1724);
            
            rmbDragItem = menu.method_34255();
            
            if (!class_1799.method_7973(carriedBefore, rmbDragItem)) {
                rmbSlotPassCounts.put(hoveredSlot, 1);
            }
        } else {
            rmbDragItem = mc.field_1724.field_7512.method_34255();
        }
        
        rmbSlotPassCounts.clear();
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleLeftClickEnd(class_310 mc, int button, int action, int mods) {
        lmbDragItem = class_1799.field_8037;
        lmbShiftDragMode = false;
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickEnd(class_310 mc, int button, int action, int mods) {
        if (rmbSlotPassCounts.isEmpty()) {
            return EventResult.pass();
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        for (Map.Entry<class_1735, Integer> entry : rmbSlotPassCounts.entrySet()) {
            class_1735 slot = entry.getKey();
            int passCount = entry.getValue();
            
            if (passCount <= 0) {
                continue;
            }
            
            for (int i = 0; i < passCount; i++) {
                if (mc.field_1761 != null) {
                    class_1799 carriedBefore = menu.method_34255();
                    if (carriedBefore.method_7960()) {
                        break;
                    }
                    
                    mc.field_1761.method_2906(containerId, slot.field_7874, 1, class_1713.field_7790, mc.field_1724);
                    
                    class_1799 carriedAfter = menu.method_34255();
                    if (class_1799.method_7973(carriedBefore, carriedAfter)) {
                        break;
                    }
                }
            }
        }
        
        rmbSlotPassCounts.clear();
        rmbDragItem = class_1799.field_8037;
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleWheelScroll(class_310 mc, double scrollDelta) {
        if (!(mc.field_1755 instanceof class_465)) {
            return EventResult.pass();
        }
        
        class_465<?> screen = (class_465<?>) mc.field_1755;
        class_1735 hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        if (hoveredSlot == null || mc.field_1761 == null) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean isPush = scrollDelta < 0;
        
        if (config.wheelScrollDirection == 1) {
            isPush = !isPush;
        } else if (config.wheelScrollDirection == 2) {
            if (hoveredSlot.field_7871 == mc.field_1724.method_31548()) {
                isPush = scrollDelta < 0;
            } else {
                isPush = scrollDelta > 0;
            }
        }
        
        if (isPush) {
            performWheelPush(mc, hoveredSlot);
        } else {
            performWheelPull(mc, hoveredSlot);
        }
        
        return EventResult.interruptDefault();
    }
    
    private static boolean isPointNearLine(int x1, int y1, int x2, int y2, int px, int py, double maxDist) {
        double lineLen = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (lineLen == 0) {
            return Math.sqrt((px - x1) * (px - x1) + (py - y1) * (py - y1)) <= maxDist;
        }
        
        double t = Math.max(0, Math.min(1, ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (lineLen * lineLen)));
        double nearestX = x1 + t * (x2 - x1);
        double nearestY = y1 + t * (y2 - y1);
        
        return Math.sqrt((px - nearestX) * (px - nearestX) + (py - nearestY) * (py - nearestY)) <= maxDist;
    }
    
    private static void performShiftClick(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null || mc.field_1724 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        mc.field_1761.method_2906(containerId, slot.field_7874, 0, class_1713.field_7794, mc.field_1724);
    }
    
    private static void performMerge(class_310 mc, class_1735 slot) {
        if (mc.field_1761 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        class_1799 slotItem = slot.method_7677();
        class_1799 carried = menu.method_34255();
        
        if (carried.method_7960() || !class_1799.method_31577(carried, slotItem)) {
            return;
        }
        
        int maxStackSize = carried.method_7914();
        int totalAmount = carried.method_7947() + slotItem.method_7947();
        
        if (totalAmount <= maxStackSize) {
            mc.field_1761.method_2906(containerId, slot.field_7874, 0, class_1713.field_7790, mc.field_1724);
        } else {
            int remaining = totalAmount - maxStackSize;
            slotItem.method_7939(remaining);
            carried.method_7939(maxStackSize);
            slot.method_7668();
        }
        
        lmbDragItem = menu.method_34255();
    }
    
    private static void performWheelPush(class_310 mc, class_1735 sourceSlot) {
        if (sourceSlot.field_7871 != mc.field_1724.method_31548()) {
            return;
        }
        
        class_1799 sourceItem = sourceSlot.method_7677();
        if (sourceItem.method_7960()) {
            return;
        }
        
        class_1735 targetSlot = findWheelTargetSlot(mc, sourceItem, false);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static void performWheelPull(class_310 mc, class_1735 sourceSlot) {
        if (sourceSlot.field_7871 == mc.field_1724.method_31548()) {
            return;
        }
        
        class_1799 sourceItem = sourceSlot.method_7677();
        if (sourceItem.method_7960()) {
            return;
        }
        
        class_1735 targetSlot = findWheelTargetSlot(mc, sourceItem, true);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static class_1735 findWheelTargetSlot(class_310 mc, class_1799 item, boolean searchPlayerInventory) {
        class_1703 menu = mc.field_1724.field_7512;
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean reverse = config.wheelSearchOrder == 1;
        
        int start = reverse ? menu.field_7761.size() - 1 : 0;
        int end = reverse ? -1 : menu.field_7761.size();
        int step = reverse ? -1 : 1;
        
        for (int i = start; i != end; i += step) {
            class_1735 slot = menu.method_7611(i);
            boolean isPlayerInventory = slot.field_7871 == mc.field_1724.method_31548();
            
            if (searchPlayerInventory != isPlayerInventory) {
                continue;
            }
            
            if (slot.method_7680(item)) {
                class_1799 slotItem = slot.method_7677();
                if (slotItem.method_7960()) {
                    return slot;
                } else if (class_1799.method_31577(item, slotItem) && slotItem.method_7947() < slotItem.method_7914()) {
                    return slot;
                }
            }
        }
        
        return null;
    }
    
    private static void transferItem(class_310 mc, class_1735 sourceSlot, class_1735 targetSlot) {
        if (mc.field_1761 == null) {
            return;
        }
        
        class_1703 menu = mc.field_1724.field_7512;
        int containerId = menu.field_7763;
        
        class_1799 sourceItem = sourceSlot.method_7677();
        class_1799 targetItem = targetSlot.method_7677();
        
        if (targetItem.method_7960()) {
            mc.field_1761.method_2906(containerId, sourceSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
            mc.field_1761.method_2906(containerId, targetSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
        } else if (class_1799.method_31577(sourceItem, targetItem)) {
            int maxStackSize = sourceItem.method_7914();
            int total = sourceItem.method_7947() + targetItem.method_7947();
            
            if (total <= maxStackSize) {
                mc.field_1761.method_2906(containerId, sourceSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
                mc.field_1761.method_2906(containerId, targetSlot.field_7874, 0, class_1713.field_7790, mc.field_1724);
            } else {
                int remaining = total - maxStackSize;
                sourceItem.method_7939(remaining);
                targetItem.method_7939(maxStackSize);
                sourceSlot.method_7668();
                targetSlot.method_7668();
            }
        }
    }
}
