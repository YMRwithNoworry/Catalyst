package org.alku.catalyst.client;

import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.alku.catalyst.client.gui.KeybindManager;

public class CatalystKeys {
    public static final String KEY_CATEGORY = "key.categories.catalyst";
    
    public static class_304 TOGGLE_AUTO_SPRINT;
    public static class_304 TOGGLE_AUTO_SWIM;
    public static class_304 TOGGLE_GAMMA_OVERRIDE;
    public static class_304 TOGGLE_AUTO_TOOL;
    public static class_304 TOGGLE_AUTO_WEAPON;
    public static class_304 OPEN_CONFIG;
    
    public static void register() {
        TOGGLE_AUTO_SPRINT = createKey("toggle_auto_sprint");
        TOGGLE_AUTO_SWIM = createKey("toggle_auto_swim");
        TOGGLE_GAMMA_OVERRIDE = createKey("toggle_gamma_override");
        TOGGLE_AUTO_TOOL = createKey("toggle_auto_tool");
        TOGGLE_AUTO_WEAPON = createKey("toggle_auto_weapon");
        OPEN_CONFIG = createKey("open_config");
        
        KeyMappingRegistry.register(TOGGLE_AUTO_SPRINT);
        KeyMappingRegistry.register(TOGGLE_AUTO_SWIM);
        KeyMappingRegistry.register(TOGGLE_GAMMA_OVERRIDE);
        KeyMappingRegistry.register(TOGGLE_AUTO_TOOL);
        KeyMappingRegistry.register(TOGGLE_AUTO_WEAPON);
        KeyMappingRegistry.register(OPEN_CONFIG);
    }
    
    private static class_304 createKey(String name) {
        int defaultKey = KeybindManager.getKey(name);
        return new class_304(
            "key.catalyst." + name,
            class_3675.class_307.field_1668,
            defaultKey,
            KEY_CATEGORY
        );
    }
}
