package org.alku.catalyst.client.gui;

import org.alku.catalyst.client.feature.GammaOverride;
import org.alku.catalyst.config.CatalystConfig;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class CatalystConfigScreen extends class_437 {
    private static final int PANEL_WIDTH = 140;
    private static final int BUTTON_HEIGHT = 22;
    private static final int PANEL_HEADER_HEIGHT = 24;
    private static final double MAX_GAMMA = 1500.0;
    
    private static final int COLOR_BG_HEADER = 0xB0181818;
    private static final int COLOR_BG_ENABLED = 0xB01A2A1A;
    private static final int COLOR_BG_DISABLED = 0xB0141414;
    private static final int COLOR_BG_HOVER_ENABLED = 0xB0223622;
    private static final int COLOR_BG_HOVER_DISABLED = 0xB01E1E1E;
    private static final int COLOR_BG_CONFIG = 0xB0101010;
    private static final int COLOR_STATUS_ON = 0xFF44DD44;
    private static final int COLOR_STATUS_OFF = 0xFF444444;
    private static final int COLOR_BORDER = 0xFF2A2A2A;
    
    private final class_437 parent;
    private List<ModulePanel> panels = new ArrayList<>();
    
    private ModulePanel draggingPanel = null;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;
    
    private boolean isDraggingSlider = false;
    private int sliderButtonIndex = -1;
    
    public CatalystConfigScreen(class_437 parent) {
        super(class_2561.method_43471("catalyst.gui.title"));
        this.parent = parent;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        panels.clear();
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        int startX = 10;
        int startY = 10;
        int spacing = 12;
        
        ModulePanel movementPanel = new ModulePanel(
            config.getPanelX("Movement", startX),
            config.getPanelY("Movement", startY),
            "Movement", this);
        movementPanel.addModule("auto_sprint", "toggle_auto_sprint", false);
        movementPanel.addModule("auto_swim", "toggle_auto_swim", false);
        panels.add(movementPanel);
        
        ModulePanel combatPanel = new ModulePanel(
            config.getPanelX("Combat", startX + (PANEL_WIDTH + spacing)),
            config.getPanelY("Combat", startY),
            "Combat", this);
        combatPanel.addModule("auto_weapon", "toggle_auto_weapon", true);
        panels.add(combatPanel);
        
        ModulePanel playerPanel = new ModulePanel(
            config.getPanelX("Player", startX + (PANEL_WIDTH + spacing) * 2),
            config.getPanelY("Player", startY),
            "Player", this);
        playerPanel.addModule("gamma_override", "toggle_gamma_override", true);
        playerPanel.addModule("auto_door", "toggle_auto_door", false);
        playerPanel.addModule("auto_water_bucket", "toggle_auto_water_bucket", false);
        playerPanel.addModule("chams", "toggle_chams", true);
        panels.add(playerPanel);
        
        ModulePanel toolsPanel = new ModulePanel(
            config.getPanelX("Tools", startX + (PANEL_WIDTH + spacing) * 3),
            config.getPanelY("Tools", startY),
            "Tools", this);
        toolsPanel.addModule("auto_tool", "toggle_auto_tool", true);
        toolsPanel.addModule("inventory_sorter", "sort_inventory", true);
        panels.add(toolsPanel);
    }
    
    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        float scale = getScale();
        float centerX = this.field_22789 / 2.0f;
        float centerY = this.field_22790 / 2.0f;
        
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(centerX, centerY, 0);
        graphics.method_51448().method_22905(scale, scale, 1.0f);
        graphics.method_51448().method_46416(-centerX, -centerY, 0);
        
        int scaledMouseX = getScaledMouseX(mouseX);
        int scaledMouseY = getScaledMouseY(mouseY);
        
        for (ModulePanel panel : panels) {
            panel.render(graphics, scaledMouseX, scaledMouseY, partialTick);
        }
        
        graphics.method_51448().method_22909();
    }
    
    private int getScaledMouseX(double mouseX) {
        float scale = getScale();
        float centerX = this.field_22789 / 2.0f;
        return (int)(centerX + (mouseX - centerX) / scale);
    }
    
    private int getScaledMouseY(double mouseY) {
        float scale = getScale();
        float centerY = this.field_22790 / 2.0f;
        return (int)(centerY + (mouseY - centerY) / scale);
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int scaledX = getScaledMouseX(mouseX);
        int scaledY = getScaledMouseY(mouseY);
        
        for (int i = panels.size() - 1; i >= 0; i--) {
            ModulePanel panel = panels.get(i);
            if (panel.isMouseOver(scaledX, scaledY)) {
                if (button == 0 && panel.isMouseOverHeader(scaledX, scaledY)) {
                    draggingPanel = panel;
                    dragOffsetX = scaledX - panel.getX();
                    dragOffsetY = scaledY - panel.getY();
                    panels.remove(i);
                    panels.add(panel);
                    return true;
                }
                if (panel.mouseClicked(scaledX, scaledY, button)) {
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (draggingPanel != null) {
                draggingPanel = null;
                savePanelPositions();
                return true;
            }
            if (isDraggingSlider) {
                isDraggingSlider = false;
                sliderButtonIndex = -1;
                return true;
            }
        }
        return super.method_25406(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        int scaledX = getScaledMouseX(mouseX);
        int scaledY = getScaledMouseY(mouseY);
        
        if (isDraggingSlider && button == 0) {
            for (ModulePanel panel : panels) {
                int expandedIndex = panel.getExpandedButton();
                if (expandedIndex >= 0 && expandedIndex < panel.buttons.size()) {
                    ModuleButton btn = panel.buttons.get(expandedIndex);
                    if (btn.featureKey.equals("gamma_override")) {
                        updateSlider(panel, scaledX);
                        return true;
                    }
                }
            }
        }
        
        if (draggingPanel != null && button == 0) {
            draggingPanel.setPosition((int)(scaledX - dragOffsetX), (int)(scaledY - dragOffsetY));
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }
    
    private void updateSlider(ModulePanel panel, int mouseX) {
        int sliderX = panel.getX() + 8;
        int sliderWidth = PANEL_WIDTH - 16;
        double newValue = ((mouseX - sliderX) / (double)sliderWidth) * MAX_GAMMA;
        newValue = Math.max(0.0, Math.min(MAX_GAMMA, newValue));
        CatalystConfig.getInstance().gammaValue = newValue;
        CatalystConfig.getInstance().save();
        if (CatalystConfig.getInstance().gammaOverrideEnabled) {
            GammaOverride.setGamma(field_22787, newValue);
        }
    }
    
    public void startSliderDrag(int buttonIndex) {
        isDraggingSlider = true;
        sliderButtonIndex = buttonIndex;
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        CatalystConfig config = CatalystConfig.getInstance();
        config.guiScale += delta * 0.1f;
        config.guiScale = Math.max(0.5f, Math.min(2.0f, config.guiScale));
        config.save();
        return true;
    }
    
    private void savePanelPositions() {
        CatalystConfig config = CatalystConfig.getInstance();
        for (ModulePanel panel : panels) {
            config.setPanelPosition(panel.getName(), panel.getX(), panel.getY());
        }
        config.save();
    }
    
    @Override
    public void method_25419() {
        savePanelPositions();
        CatalystConfig.getInstance().save();
        this.field_22787.method_1507(parent);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    public float getScale() {
        return CatalystConfig.getInstance().guiScale;
    }
    
    public static class ModulePanel {
        private int x;
        private int y;
        private final String name;
        private final CatalystConfigScreen parent;
        private final List<ModuleButton> buttons = new ArrayList<>();
        private int height;
        private int expandedButton = -1;
        
        public ModulePanel(int x, int y, String name, CatalystConfigScreen parent) {
            this.x = x;
            this.y = y;
            this.name = name;
            this.parent = parent;
            this.height = PANEL_HEADER_HEIGHT;
        }
        
        public void addModule(String featureKey, String keybindKey, boolean hasConfig) {
            buttons.add(new ModuleButton(featureKey, keybindKey, this, hasConfig));
            height += BUTTON_HEIGHT;
        }
        
        public int getX() { return x; }
        public int getY() { return y; }
        public String getName() { return name; }
        public void setPosition(int newX, int newY) { this.x = newX; this.y = newY; }
        public int getExpandedButton() { return expandedButton; }
        public void setExpandedButton(int index) { this.expandedButton = index; }
        
        public boolean isMouseOver(double mouseX, double mouseY) {
            int totalHeight = height;
            if (expandedButton >= 0 && expandedButton < buttons.size()) {
                totalHeight += buttons.get(expandedButton).getConfigHeight();
            }
            return mouseX >= x && mouseX <= x + PANEL_WIDTH && mouseY >= y && mouseY <= y + totalHeight;
        }
        
        public boolean isMouseOverHeader(double mouseX, double mouseY) {
            return mouseX >= x && mouseX <= x + PANEL_WIDTH && mouseY >= y && mouseY <= y + PANEL_HEADER_HEIGHT;
        }
        
        public void render(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            graphics.method_25294(x, y, x + PANEL_WIDTH, y + PANEL_HEADER_HEIGHT, CatalystConfigScreen.COLOR_BG_HEADER);
            graphics.method_25294(x, y, x + 1, y + PANEL_HEADER_HEIGHT, CatalystConfigScreen.COLOR_BORDER);
            graphics.method_25294(x + PANEL_WIDTH - 1, y, x + PANEL_WIDTH, y + PANEL_HEADER_HEIGHT, CatalystConfigScreen.COLOR_BORDER);
            graphics.method_25294(x, y, x + PANEL_WIDTH, y + 1, CatalystConfigScreen.COLOR_BORDER);
            
            graphics.method_27534(parent.field_22787.field_1772, class_2561.method_43470(name), x + PANEL_WIDTH / 2, y + 7, 0xFFFFFFFF);
            
            int currentY = y + PANEL_HEADER_HEIGHT;
            for (int i = 0; i < buttons.size(); i++) {
                ModuleButton button = buttons.get(i);
                boolean isLast = (i == buttons.size() - 1);
                
                button.render(graphics, x, currentY, mouseX, mouseY, isLast);
                
                if (i == expandedButton) {
                    currentY += button.getConfigHeight();
                }
                currentY += BUTTON_HEIGHT;
            }
            
            int totalHeight = currentY - y;
            graphics.method_25294(x, y + totalHeight - 1, x + PANEL_WIDTH, y + totalHeight, CatalystConfigScreen.COLOR_BORDER);
            graphics.method_25294(x, y + PANEL_HEADER_HEIGHT, x + 1, y + totalHeight, CatalystConfigScreen.COLOR_BORDER);
            graphics.method_25294(x + PANEL_WIDTH - 1, y + PANEL_HEADER_HEIGHT, x + PANEL_WIDTH, y + totalHeight, CatalystConfigScreen.COLOR_BORDER);
        }
        
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            int currentY = y + PANEL_HEADER_HEIGHT;
            for (int i = 0; i < buttons.size(); i++) {
                int btnHeight = BUTTON_HEIGHT;
                if (i == expandedButton) {
                    btnHeight += buttons.get(i).getConfigHeight();
                }
                
                if (mouseY >= currentY && mouseY <= currentY + btnHeight) {
                    if (buttons.get(i).mouseClicked(mouseX, mouseY, button, currentY)) {
                        return true;
                    }
                }
                currentY += btnHeight;
            }
            return false;
        }
        
        public CatalystConfigScreen getParentScreen() { return parent; }
    }
    
    public static class ModuleButton {
        private final String featureKey;
        private final String keybindKey;
        private final ModulePanel panel;
        private final boolean hasConfig;
        
        public ModuleButton(String featureKey, String keybindKey, ModulePanel panel, boolean hasConfig) {
            this.featureKey = featureKey;
            this.keybindKey = keybindKey;
            this.panel = panel;
            this.hasConfig = hasConfig;
        }
        
        public int getConfigHeight() {
            if (featureKey.equals("gamma_override")) {
                return 50;
            }
            if (featureKey.equals("auto_weapon")) {
                return 70;
            }
            if (featureKey.equals("auto_tool")) {
                return 70;
            }
            if (featureKey.equals("chams")) {
                return 50;
            }
            if (featureKey.equals("inventory_sorter")) {
                return 90;
            }
            return 0;
        }
        
        public void render(class_332 graphics, int x, int y, int mouseX, int mouseY, boolean isLast) {
            CatalystConfig config = CatalystConfig.getInstance();
            boolean isEnabled = getEnabledState(config);
            boolean isExpanded = (panel.getExpandedButton() >= 0 && panel.buttons.get(panel.getExpandedButton()) == this);
            
            int bgColor = isEnabled ? CatalystConfigScreen.COLOR_BG_ENABLED : CatalystConfigScreen.COLOR_BG_DISABLED;
            int hoverColor = isEnabled ? CatalystConfigScreen.COLOR_BG_HOVER_ENABLED : CatalystConfigScreen.COLOR_BG_HOVER_DISABLED;
            
            boolean isHovered = mouseX >= x && mouseX <= x + PANEL_WIDTH && mouseY >= y && mouseY <= y + BUTTON_HEIGHT;
            int drawColor = isHovered ? hoverColor : bgColor;
            
            graphics.method_25294(x, y, x + PANEL_WIDTH, y + BUTTON_HEIGHT, drawColor);
            
            int statusColor = isEnabled ? CatalystConfigScreen.COLOR_STATUS_ON : CatalystConfigScreen.COLOR_STATUS_OFF;
            graphics.method_25294(x + 4, y + 6, x + 8, y + BUTTON_HEIGHT - 6, statusColor);
            
            class_2561 featureName = class_2561.method_43471("catalyst.feature." + featureKey);
            graphics.method_27535(panel.getParentScreen().field_22787.field_1772, featureName, x + 12, y + 6, 0xFFFFFFFF);
            
            String keybindText = KeybindManager.getBoundKey(keybindKey);
            class_2561 keybindComponent = class_2561.method_43470("[" + keybindText + "]");
            int textWidth = panel.getParentScreen().field_22787.field_1772.method_27525(keybindComponent);
            graphics.method_27535(panel.getParentScreen().field_22787.field_1772, keybindComponent, x + PANEL_WIDTH - 5 - textWidth, y + 6, 0xFFAAAAAA);
            
            if (isExpanded && featureKey.equals("gamma_override")) {
                int configY = y + BUTTON_HEIGHT;
                graphics.method_25294(x, configY, x + PANEL_WIDTH, configY + 50, CatalystConfigScreen.COLOR_BG_CONFIG);
                
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, "Gamma: " + String.format("%.1f", config.gammaValue), x + 8, configY + 6, 0xFFCCCCCC);
                
                int sliderX = x + 8;
                int sliderWidth = PANEL_WIDTH - 16;
                int sliderY = configY + 20;
                
                graphics.method_25294(sliderX, sliderY, sliderX + sliderWidth, sliderY + 8, 0xFF333333);
                
                int filledWidth = (int)(sliderWidth * (config.gammaValue / MAX_GAMMA));
                graphics.method_25294(sliderX, sliderY, sliderX + filledWidth, sliderY + 8, 0xFF44AA44);
                
                int handleX = sliderX + filledWidth - 4;
                graphics.method_25294(handleX, sliderY - 2, handleX + 8, sliderY + 10, 0xFFFFFFFF);
                
                String modeText = config.nightVisionMode ? "Mode: Full Bright" : "Mode: Custom";
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, modeText, x + 8, configY + 34, 0xFF55FF55);
            }
            
            if (isExpanded && featureKey.equals("auto_weapon")) {
                int configY = y + BUTTON_HEIGHT;
                graphics.method_25294(x, configY, x + PANEL_WIDTH, configY + 70, CatalystConfigScreen.COLOR_BG_CONFIG);
                
                String restoreText = class_2561.method_43469("catalyst.gui.restore_slot", 
                    config.autoWeaponRestore ? class_2561.method_43471("catalyst.gui.on").getString() : class_2561.method_43471("catalyst.gui.off").getString()).getString();
                int restoreColor = config.autoWeaponRestore ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, restoreText, x + 8, configY + 6, restoreColor);
                
                int lockedSlot = config.autoWeaponLockedSlot;
                String slotText = lockedSlot >= 0 ? 
                    class_2561.method_43469("catalyst.gui.locked_slot", lockedSlot + 1).getString() :
                    class_2561.method_43471("catalyst.gui.no_locked_slot").getString();
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, slotText, x + 8, configY + 20, 0xFFCCCCCC);
                
                int slotStartX = x + 8;
                int slotY = configY + 34;
                int slotSize = 12;
                int slotSpacing = 2;
                
                for (int i = 0; i < 9; i++) {
                    int slotX = slotStartX + i * (slotSize + slotSpacing);
                    boolean isSelected = (i == lockedSlot);
                    int slotColor = isSelected ? 0xFF44AA44 : 0xFF333333;
                    int borderColor = isSelected ? 0xFF55FF55 : 0xFF555555;
                    
                    graphics.method_25294(slotX - 1, slotY - 1, slotX + slotSize + 1, slotY + slotSize + 1, borderColor);
                    graphics.method_25294(slotX, slotY, slotX + slotSize, slotY + slotSize, slotColor);
                    
                    String slotNum = String.valueOf(i + 1);
                    graphics.method_25300(panel.getParentScreen().field_22787.field_1772, slotNum, slotX + slotSize / 2, slotY + 2, 0xFFFFFFFF);
                }
                
                String hint = class_2561.method_43471("catalyst.gui.click_to_lock").getString();
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, hint, x + 8, configY + 52, 0xFF888888);
            }
            
            if (isExpanded && featureKey.equals("auto_tool")) {
                int configY = y + BUTTON_HEIGHT;
                graphics.method_25294(x, configY, x + PANEL_WIDTH, configY + 70, CatalystConfigScreen.COLOR_BG_CONFIG);
                
                String restoreText = class_2561.method_43469("catalyst.gui.restore_slot", 
                    config.autoToolRestore ? class_2561.method_43471("catalyst.gui.on").getString() : class_2561.method_43471("catalyst.gui.off").getString()).getString();
                int restoreColor = config.autoToolRestore ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, restoreText, x + 8, configY + 6, restoreColor);
                
                int lockedSlot = config.autoToolLockedSlot;
                String slotText = lockedSlot >= 0 ? 
                    class_2561.method_43469("catalyst.gui.locked_slot", lockedSlot + 1).getString() :
                    class_2561.method_43471("catalyst.gui.no_locked_slot").getString();
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, slotText, x + 8, configY + 20, 0xFFCCCCCC);
                
                int slotStartX = x + 8;
                int slotY = configY + 34;
                int slotSize = 12;
                int slotSpacing = 2;
                
                for (int i = 0; i < 9; i++) {
                    int slotX = slotStartX + i * (slotSize + slotSpacing);
                    boolean isSelected = (i == lockedSlot);
                    int slotColor = isSelected ? 0xFF44AA44 : 0xFF333333;
                    int borderColor = isSelected ? 0xFF55FF55 : 0xFF555555;
                    
                    graphics.method_25294(slotX - 1, slotY - 1, slotX + slotSize + 1, slotY + slotSize + 1, borderColor);
                    graphics.method_25294(slotX, slotY, slotX + slotSize, slotY + slotSize, slotColor);
                    
                    String slotNum = String.valueOf(i + 1);
                    graphics.method_25300(panel.getParentScreen().field_22787.field_1772, slotNum, slotX + slotSize / 2, slotY + 2, 0xFFFFFFFF);
                }
                
                String hint = class_2561.method_43471("catalyst.gui.click_to_lock").getString();
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, hint, x + 8, configY + 52, 0xFF888888);
            }
            
            if (isExpanded && featureKey.equals("chams")) {
                int configY = y + BUTTON_HEIGHT;
                graphics.method_25294(x, configY, x + PANEL_WIDTH, configY + 50, CatalystConfigScreen.COLOR_BG_CONFIG);
                
                String playersText = class_2561.method_43471("catalyst.gui.chams_players").getString();
                int playersColor = config.chamsPlayers ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, playersText, x + 8, configY + 6, playersColor);
                
                String animalsText = class_2561.method_43471("catalyst.gui.chams_animals").getString();
                int animalsColor = config.chamsAnimals ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, animalsText, x + 8, configY + 20, animalsColor);
                
                String monstersText = class_2561.method_43471("catalyst.gui.chams_monsters").getString();
                int monstersColor = config.chamsMonsters ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, monstersText, x + 8, configY + 34, monstersColor);
            }
            
            if (isExpanded && featureKey.equals("inventory_sorter")) {
                int configY = y + BUTTON_HEIGHT;
                graphics.method_25294(x, configY, x + PANEL_WIDTH, configY + 90, CatalystConfigScreen.COLOR_BG_CONFIG);
                
                String autoSortText = class_2561.method_43469("catalyst.gui.auto_sort_on_open", 
                    config.autoSortOnOpen ? class_2561.method_43471("catalyst.gui.on").getString() : class_2561.method_43471("catalyst.gui.off").getString()).getString();
                int autoSortColor = config.autoSortOnOpen ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, autoSortText, x + 8, configY + 6, autoSortColor);
                
                String sortHotbarText = class_2561.method_43469("catalyst.gui.sort_hotbar", 
                    config.sortHotbar ? class_2561.method_43471("catalyst.gui.on").getString() : class_2561.method_43471("catalyst.gui.off").getString()).getString();
                int sortHotbarColor = config.sortHotbar ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, sortHotbarText, x + 8, configY + 20, sortHotbarColor);
                
                String sortPlayerText = class_2561.method_43469("catalyst.gui.sort_player_inv", 
                    config.sortPlayerInventoryInContainer ? class_2561.method_43471("catalyst.gui.on").getString() : class_2561.method_43471("catalyst.gui.off").getString()).getString();
                int sortPlayerColor = config.sortPlayerInventoryInContainer ? 0xFF55FF55 : 0xFF555555;
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, sortPlayerText, x + 8, configY + 34, sortPlayerColor);
                
                String[] modes = {"Category", "Name", "ID"};
                String modeText = class_2561.method_43469("catalyst.gui.sort_mode", modes[config.sortMode]).getString();
                graphics.method_25303(panel.getParentScreen().field_22787.field_1772, modeText, x + 8, configY + 48, 0xFFCCCCCC);
                
                int modeBtnX = x + 8;
                int modeBtnY = configY + 62;
                int modeBtnWidth = (PANEL_WIDTH - 20) / 3;
                for (int i = 0; i < 3; i++) {
                    int btnX = modeBtnX + i * (modeBtnWidth + 4);
                    boolean isSelected = (config.sortMode == i);
                    int btnColor = isSelected ? 0xFF44AA44 : 0xFF333333;
                    int borderColor = isSelected ? 0xFF55FF55 : 0xFF555555;
                    
                    graphics.method_25294(btnX - 1, modeBtnY - 1, btnX + modeBtnWidth + 1, modeBtnY + 18, borderColor);
                    graphics.method_25294(btnX, modeBtnY, btnX + modeBtnWidth, modeBtnY + 17, btnColor);
                    
                    graphics.method_25300(panel.getParentScreen().field_22787.field_1772, modes[i], btnX + modeBtnWidth / 2, modeBtnY + 4, 0xFFFFFFFF);
                }
            }
        }
        
        private boolean getEnabledState(CatalystConfig config) {
            if (featureKey.equals("auto_sprint")) return config.autoSprintEnabled;
            if (featureKey.equals("auto_swim")) return config.autoSwimEnabled;
            if (featureKey.equals("gamma_override")) return config.gammaOverrideEnabled;
            if (featureKey.equals("auto_tool")) return config.autoToolEnabled;
            if (featureKey.equals("auto_weapon")) return config.autoWeaponEnabled;
            if (featureKey.equals("auto_door")) return config.autoDoorEnabled;
            if (featureKey.equals("auto_water_bucket")) return config.autoWaterBucketEnabled;
            if (featureKey.equals("chams")) return config.chamsEnabled;
            if (featureKey.equals("inventory_sorter")) return config.inventorySorterEnabled;
            return false;
        }
        
        public boolean mouseClicked(double mouseX, double mouseY, int button, int buttonY) {
            if (button == 0) {
                if (mouseY >= buttonY && mouseY <= buttonY + BUTTON_HEIGHT) {
                    toggleFeature();
                    return true;
                }
                
                if (featureKey.equals("gamma_override") && panel.getExpandedButton() >= 0) {
                    int configY = buttonY + BUTTON_HEIGHT;
                    
                    if (mouseY >= configY + 18 && mouseY <= configY + 30) {
                        int sliderX = panel.getX() + 8;
                        int sliderWidth = PANEL_WIDTH - 16;
                        double newValue = ((mouseX - sliderX) / (double)sliderWidth) * MAX_GAMMA;
                        newValue = Math.max(0.0, Math.min(MAX_GAMMA, newValue));
                        CatalystConfig.getInstance().gammaValue = newValue;
                        CatalystConfig.getInstance().save();
                        if (CatalystConfig.getInstance().gammaOverrideEnabled) {
                            GammaOverride.setGamma(panel.getParentScreen().field_22787, newValue);
                        }
                        
                        int myIndex = -1;
                        for (int i = 0; i < panel.buttons.size(); i++) {
                            if (panel.buttons.get(i) == this) {
                                myIndex = i;
                                break;
                            }
                        }
                        panel.getParentScreen().startSliderDrag(myIndex);
                        return true;
                    }
                    
                    if (mouseY >= configY + 34 && mouseY <= configY + 46) {
                        CatalystConfig.getInstance().nightVisionMode = !CatalystConfig.getInstance().nightVisionMode;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                }
                
                if (featureKey.equals("auto_weapon") && panel.getExpandedButton() >= 0) {
                    int configY = buttonY + BUTTON_HEIGHT;
                    
                    if (mouseY >= configY + 4 && mouseY <= configY + 16) {
                        CatalystConfig.getInstance().autoWeaponRestore = !CatalystConfig.getInstance().autoWeaponRestore;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    int slotStartX = panel.getX() + 8;
                    int slotY = configY + 34;
                    int slotSize = 12;
                    int slotSpacing = 2;
                    
                    if (mouseY >= slotY - 1 && mouseY <= slotY + slotSize + 1) {
                        for (int i = 0; i < 9; i++) {
                            int slotX = slotStartX + i * (slotSize + slotSpacing);
                            if (mouseX >= slotX - 1 && mouseX <= slotX + slotSize + 1) {
                                int currentLocked = CatalystConfig.getInstance().autoWeaponLockedSlot;
                                if (currentLocked == i) {
                                    CatalystConfig.getInstance().autoWeaponLockedSlot = -1;
                                } else {
                                    CatalystConfig.getInstance().autoWeaponLockedSlot = i;
                                }
                                CatalystConfig.getInstance().save();
                                return true;
                            }
                        }
                    }
                }
                
                if (featureKey.equals("auto_tool") && panel.getExpandedButton() >= 0) {
                    int configY = buttonY + BUTTON_HEIGHT;
                    
                    if (mouseY >= configY + 4 && mouseY <= configY + 16) {
                        CatalystConfig.getInstance().autoToolRestore = !CatalystConfig.getInstance().autoToolRestore;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    int slotStartX = panel.getX() + 8;
                    int slotY = configY + 34;
                    int slotSize = 12;
                    int slotSpacing = 2;
                    
                    if (mouseY >= slotY - 1 && mouseY <= slotY + slotSize + 1) {
                        for (int i = 0; i < 9; i++) {
                            int slotX = slotStartX + i * (slotSize + slotSpacing);
                            if (mouseX >= slotX - 1 && mouseX <= slotX + slotSize + 1) {
                                int currentLocked = CatalystConfig.getInstance().autoToolLockedSlot;
                                if (currentLocked == i) {
                                    CatalystConfig.getInstance().autoToolLockedSlot = -1;
                                } else {
                                    CatalystConfig.getInstance().autoToolLockedSlot = i;
                                }
                                CatalystConfig.getInstance().save();
                                return true;
                            }
                        }
                    }
                }
                
                if (featureKey.equals("chams") && panel.getExpandedButton() >= 0) {
                    int configY = buttonY + BUTTON_HEIGHT;
                    
                    if (mouseY >= configY + 4 && mouseY <= configY + 16) {
                        CatalystConfig.getInstance().chamsPlayers = !CatalystConfig.getInstance().chamsPlayers;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    if (mouseY >= configY + 18 && mouseY <= configY + 30) {
                        CatalystConfig.getInstance().chamsAnimals = !CatalystConfig.getInstance().chamsAnimals;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    if (mouseY >= configY + 32 && mouseY <= configY + 44) {
                        CatalystConfig.getInstance().chamsMonsters = !CatalystConfig.getInstance().chamsMonsters;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                }
                
                if (featureKey.equals("inventory_sorter") && panel.getExpandedButton() >= 0) {
                    int configY = buttonY + BUTTON_HEIGHT;
                    
                    if (mouseY >= configY + 4 && mouseY <= configY + 16) {
                        CatalystConfig.getInstance().autoSortOnOpen = !CatalystConfig.getInstance().autoSortOnOpen;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    if (mouseY >= configY + 18 && mouseY <= configY + 30) {
                        CatalystConfig.getInstance().sortHotbar = !CatalystConfig.getInstance().sortHotbar;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    if (mouseY >= configY + 32 && mouseY <= configY + 44) {
                        CatalystConfig.getInstance().sortPlayerInventoryInContainer = !CatalystConfig.getInstance().sortPlayerInventoryInContainer;
                        CatalystConfig.getInstance().save();
                        return true;
                    }
                    
                    int modeBtnX = panel.getX() + 8;
                    int modeBtnY = configY + 62;
                    int modeBtnWidth = (PANEL_WIDTH - 20) / 3;
                    
                    if (mouseY >= modeBtnY - 1 && mouseY <= modeBtnY + 18) {
                        for (int i = 0; i < 3; i++) {
                            int btnX = modeBtnX + i * (modeBtnWidth + 4);
                            if (mouseX >= btnX - 1 && mouseX <= btnX + modeBtnWidth + 1) {
                                CatalystConfig.getInstance().sortMode = i;
                                CatalystConfig.getInstance().save();
                                return true;
                            }
                        }
                    }
                }
            } else if (button == 1 && hasConfig) {
                int myIndex = -1;
                for (int i = 0; i < panel.buttons.size(); i++) {
                    if (panel.buttons.get(i) == this) {
                        myIndex = i;
                        break;
                    }
                }
                if (panel.getExpandedButton() == myIndex) {
                    panel.setExpandedButton(-1);
                } else {
                    panel.setExpandedButton(myIndex);
                }
                return true;
            }
            return false;
        }
        
        private void toggleFeature() {
            CatalystConfig config = CatalystConfig.getInstance();
            
            if (featureKey.equals("auto_sprint")) config.autoSprintEnabled = !config.autoSprintEnabled;
            else if (featureKey.equals("auto_swim")) config.autoSwimEnabled = !config.autoSwimEnabled;
            else if (featureKey.equals("gamma_override")) config.gammaOverrideEnabled = !config.gammaOverrideEnabled;
            else if (featureKey.equals("auto_tool")) config.autoToolEnabled = !config.autoToolEnabled;
            else if (featureKey.equals("auto_weapon")) config.autoWeaponEnabled = !config.autoWeaponEnabled;
            else if (featureKey.equals("auto_door")) config.autoDoorEnabled = !config.autoDoorEnabled;
            else if (featureKey.equals("auto_water_bucket")) config.autoWaterBucketEnabled = !config.autoWaterBucketEnabled;
            else if (featureKey.equals("chams")) config.chamsEnabled = !config.chamsEnabled;
            else if (featureKey.equals("inventory_sorter")) config.inventorySorterEnabled = !config.inventorySorterEnabled;
            
            config.save();
        }
    }
}
