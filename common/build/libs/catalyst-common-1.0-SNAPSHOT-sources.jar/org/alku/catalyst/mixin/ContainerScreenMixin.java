package org.alku.catalyst.mixin;

import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.alku.catalyst.client.feature.InventorySorter;
import org.alku.catalyst.config.CatalystConfig;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class ContainerScreenMixin extends class_437 {
    @Shadow protected int leftPos;
    @Shadow protected int topPos;
    @Shadow @Final protected class_1703 menu;
    @Shadow protected int imageWidth;
    @Shadow protected int imageHeight;
    
    @Unique
    private class_4185 catalyst$sortButton;
    
    protected ContainerScreenMixin(class_2561 title) {
        super(title);
    }
    
    @Inject(method = "init", at = @At("TAIL"))
    protected void onInit(CallbackInfo ci) {
        if (!CatalystConfig.getInstance().inventorySorterEnabled) {
            return;
        }
        
        catalyst$sortButton = class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.sort_button"),
            button -> {
                class_310 mc = class_310.method_1551();
                if (mc.field_1724 != null && !InventorySorter.isSorting()) {
                    InventorySorter.sortCurrentContainer(mc);
                }
            }
        ).method_46434(leftPos + imageWidth - 60, topPos + 4, 56, 18).method_46431();
        
        this.method_37063(catalyst$sortButton);
        
        if (CatalystConfig.getInstance().autoSortOnOpen && !InventorySorter.isSorting()) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null) {
                InventorySorter.sortCurrentContainer(mc);
            }
        }
    }
    
    @Inject(method = "render", at = @At("HEAD"))
    protected void onRender(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (catalyst$sortButton != null) {
            catalyst$sortButton.method_46421(leftPos + imageWidth - 60);
            catalyst$sortButton.method_46419(topPos + 4);
        }
    }
}
