package org.alku.catalyst.mixin;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.alku.catalyst.client.waypoint.WaypointRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WaypointRenderMixin {
    
    @Inject(
        method = "renderLevel",
        at = @At("RETURN")
    )
    private void afterRenderLevel(class_4587 poseStack, float partialTick, long finishNanoTime, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightTexture, Matrix4f projectionMatrix, CallbackInfo ci) {
        WaypointRenderer.renderWaypoints(poseStack, partialTick);
    }
}
