package org.alku.catalyst.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_765;
import org.alku.catalyst.config.CatalystConfig;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_765.class)
public class LightTextureMixin {
    
    @Shadow @Final private class_1011 lightPixels;
    @Shadow @Final private class_1043 lightTexture;
    @Shadow private boolean updateLightTexture;
    
    @Inject(
        method = "updateLightTexture",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onUpdateLightTexture(CallbackInfo ci) {
        CatalystConfig config = CatalystConfig.getInstance();
        if (config.gammaOverrideEnabled && config.gammaValue >= 100) {
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    this.lightPixels.method_4305(x, y, -1);
                }
            }
            this.lightTexture.method_4524();
            this.updateLightTexture = false;
            ci.cancel();
        }
    }
}
