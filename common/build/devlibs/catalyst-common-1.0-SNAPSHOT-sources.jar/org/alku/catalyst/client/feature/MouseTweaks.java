package org.alku.catalyst.client.feature;

import dev.architectury.event.EventResult;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.alku.catalyst.config.CatalystConfig;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class MouseTweaks {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("MouseTweaks");
    
    private static boolean mouseLeftDown = false;
    private static boolean mouseRightDown = false;
    private static int lastMouseX = -1;
    private static int lastMouseY = -1;
    private static Slot lastHoveredSlot = null;
    private static boolean isDragging = false;
    private static int dragStartX = -1;
    private static int dragStartY = -1;
    private static int dragButton = -1;
    
    private static Map<Slot, Integer> rmbSlotPassCounts = new HashMap<>();
    private static ItemStack rmbDragItem = ItemStack.EMPTY;
    
    private static ItemStack lmbDragItem = ItemStack.EMPTY;
    private static boolean lmbShiftDragMode = false;
    
    public static void init() {
    }
    
    public static void tick(Minecraft mc) {
        if (mc.screen instanceof AbstractContainerScreen) {
            double mouseX = mc.mouseHandler.xpos();
            double mouseY = mc.mouseHandler.ypos();
            
            double guiScale = mc.getWindow().getGuiScale();
            int scaledMouseX = (int) (mouseX / guiScale);
            int scaledMouseY = (int) (mouseY / guiScale);
            
            onMouseMove(mc, scaledMouseX, scaledMouseY);
        }
    }
    
    private static Slot getHoveredSlot(AbstractContainerScreen<?> screen, int mouseX, int mouseY) {
        if (screen == null) {
            return null;
        }
        
        try {
            Field hoveredSlotField = AbstractContainerScreen.class.getDeclaredField("hoveredSlot");
            hoveredSlotField.setAccessible(true);
            Slot hoveredSlot = (Slot) hoveredSlotField.get(screen);
            return hoveredSlot;
        } catch (Exception e) {
            try {
                Field leftPosField = AbstractContainerScreen.class.getDeclaredField("leftPos");
                Field topPosField = AbstractContainerScreen.class.getDeclaredField("topPos");
                leftPosField.setAccessible(true);
                topPosField.setAccessible(true);
                
                int leftPos = leftPosField.getInt(screen);
                int topPos = topPosField.getInt(screen);
                
                int relX = mouseX - leftPos;
                int relY = mouseY - topPos;
                
                for (int i = 0; i < screen.getMenu().slots.size(); i++) {
                    Slot slot = screen.getMenu().getSlot(i);
                    if (relX >= slot.x && relX < slot.x + 16 && relY >= slot.y && relY < slot.y + 16) {
                        return slot;
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        return null;
    }
    
    private static boolean isShiftKeyDown(Minecraft mc) {
        return mc.options.keyShift.isDown() || 
               GLFW.glfwGetKey(mc.getWindow().getWindow(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS ||
               GLFW.glfwGetKey(mc.getWindow().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }
    
    public static EventResult onMouseClicked(Minecraft mc, int button, int action, int mods) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!(mc.screen instanceof AbstractContainerScreen)) {
            return EventResult.pass();
        }
        
        if (action == 1) {
            if (button == 0) {
                mouseLeftDown = true;
                dragButton = 0;
                dragStartX = lastMouseX;
                dragStartY = lastMouseY;
                
                if (config.lmbTweakWithItem || config.lmbTweakWithoutItem) {
                    return handleLeftClickStart(mc, button, action, mods);
                }
            } else if (button == 1) {
                mouseRightDown = true;
                dragButton = 1;
                dragStartX = lastMouseX;
                dragStartY = lastMouseY;
                
                if (config.rmbTweak) {
                    return handleRightClickStart(mc, button, action, mods);
                }
            }
        } else if (action == 0) {
            if (button == 0) {
                mouseLeftDown = false;
                if (isDragging && dragButton == 0) {
                    isDragging = false;
                    return handleLeftClickEnd(mc, button, action, mods);
                }
            } else if (button == 1) {
                mouseRightDown = false;
                if (isDragging && dragButton == 1) {
                    isDragging = false;
                    return handleRightClickEnd(mc, button, action, mods);
                }
            }
        }
        
        return EventResult.pass();
    }
    
    public static EventResult onMouseScrolled(Minecraft mc, double scrollDelta) {
        CatalystConfig config = CatalystConfig.getInstance();
        
        if (!config.wheelTweak || !(mc.screen instanceof AbstractContainerScreen)) {
            return EventResult.pass();
        }
        
        return handleWheelScroll(mc, scrollDelta);
    }
    
    public static void onMouseMove(Minecraft mc, double mouseX, double mouseY) {
        int currentMouseX = (int) mouseX;
        int currentMouseY = (int) mouseY;
        
        if (!(mc.screen instanceof AbstractContainerScreen)) {
            lastMouseX = currentMouseX;
            lastMouseY = currentMouseY;
            return;
        }
        
        AbstractContainerScreen<?> screen = (AbstractContainerScreen<?>) mc.screen;
        Slot hoveredSlot = getHoveredSlot(screen, currentMouseX, currentMouseY);
        
        if ((mouseLeftDown || mouseRightDown) && !isDragging) {
            int dx = Math.abs(currentMouseX - dragStartX);
            int dy = Math.abs(currentMouseY - dragStartY);
            
            if (dx > 3 || dy > 3) {
                isDragging = true;
                System.out.println("[MouseTweaks] Drag started - dragButton=" + dragButton + ", lmbShiftDragMode=" + lmbShiftDragMode);
            }
        }
        
        if (isDragging) {
            processAllSlotsAlongPath(mc, lastMouseX, lastMouseY, currentMouseX, currentMouseY, screen);
        }
        
        lastHoveredSlot = hoveredSlot;
        lastMouseX = currentMouseX;
        lastMouseY = currentMouseY;
    }
    
    private static void processAllSlotsAlongPath(Minecraft mc, int x1, int y1, int x2, int y2, AbstractContainerScreen<?> screen) {
        if (dragButton != 0) {
            return;
        }
        
        boolean shiftDown = isShiftKeyDown(mc);
        
        try {
            Field leftPosField = AbstractContainerScreen.class.getDeclaredField("leftPos");
            Field topPosField = AbstractContainerScreen.class.getDeclaredField("topPos");
            leftPosField.setAccessible(true);
            topPosField.setAccessible(true);
            
            int leftPos = leftPosField.getInt(screen);
            int topPos = topPosField.getInt(screen);
            
            int processedCount = 0;
            for (int i = 0; i < screen.getMenu().slots.size(); i++) {
                Slot slot = screen.getMenu().getSlot(i);
                int slotScreenX = leftPos + slot.x + 8;
                int slotScreenY = topPos + slot.y + 8;
                
                double dist = pointToLineDistance(x1, y1, x2, y2, slotScreenX, slotScreenY);
                if (dist <= 12) {
                    System.out.println("[MouseTweaks] Slot " + i + " at (" + slotScreenX + "," + slotScreenY + ") mouse(" + x1 + "," + y1 + ")-(" + x2 + "," + y2 + ") dist=" + String.format("%.1f", dist));
                    processSlot(mc, slot, shiftDown);
                    processedCount++;
                }
            }
            if (processedCount > 0) {
                System.out.println("[MouseTweaks] Processed " + processedCount + " slots, mouse from(" + x1 + "," + y1 + ") to(" + x2 + "," + y2 + ")");
            }
        } catch (Exception e) {
            System.out.println("[MouseTweaks] ERROR in processAllSlotsAlongPath: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static double pointToLineDistance(int x1, int y1, int x2, int y2, int px, int py) {
        double lineLen = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (lineLen == 0) {
            return Math.sqrt((px - x1) * (px - x1) + (py - y1) * (py - y1));
        }
        
        double t = Math.max(0, Math.min(1, ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (lineLen * lineLen)));
        double nearestX = x1 + t * (x2 - x1);
        double nearestY = y1 + t * (y2 - y1);
        
        return Math.sqrt((px - nearestX) * (px - nearestX) + (py - nearestY) * (py - nearestY));
    }
    
    private static void processSlot(Minecraft mc, Slot slot, boolean shiftDown) {
        System.out.println("[MouseTweaks] processSlot - lmbShiftDragMode=" + lmbShiftDragMode + ", shiftDown=" + shiftDown + ", slotIndex=" + slot.index + ", slotHasItem=" + !slot.getItem().isEmpty());
        
        if (lmbShiftDragMode) {
            if (shiftDown && !slot.getItem().isEmpty()) {
                System.out.println("[MouseTweaks] Performing shift click on slot " + slot.index);
                performShiftClick(mc, slot);
            }
        } else if (!lmbDragItem.isEmpty()) {
            ItemStack slotItem = slot.getItem();
            if (!slotItem.isEmpty() && ItemStack.isSameItemSameTags(lmbDragItem, slotItem)) {
                if (shiftDown) {
                    performShiftClick(mc, slot);
                } else {
                    performMerge(mc, slot);
                }
            }
        }
    }
    
    private static EventResult handleLeftClickStart(Minecraft mc, int button, int action, int mods) {
        if (!(mc.screen instanceof AbstractContainerScreen)) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        boolean shiftDown = isShiftKeyDown(mc);
        AbstractContainerScreen<?> screen = (AbstractContainerScreen<?>) mc.screen;
        Slot hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        System.out.println("[MouseTweaks] Left click start - shiftDown=" + shiftDown + ", lmbTweakWithoutItem=" + config.lmbTweakWithoutItem);
        
        lmbShiftDragMode = false;
        lmbDragItem = ItemStack.EMPTY;
        
        if (shiftDown && config.lmbTweakWithoutItem) {
            lmbShiftDragMode = true;
            System.out.println("[MouseTweaks] Entering Shift drag mode");
            return EventResult.interruptDefault();
        }
        
        if (hoveredSlot != null && mc.gameMode != null) {
            AbstractContainerMenu menu = mc.player.containerMenu;
            int containerId = menu.containerId;
            
            ItemStack carriedBefore = menu.getCarried();
            
            if (carriedBefore.isEmpty()) {
                if (config.lmbTweakWithItem) {
                    mc.gameMode.handleInventoryMouseClick(containerId, hoveredSlot.index, 0, ClickType.PICKUP, mc.player);
                    lmbDragItem = menu.getCarried();
                    System.out.println("[MouseTweaks] Picked up item: " + !lmbDragItem.isEmpty());
                } else {
                    return EventResult.pass();
                }
            } else {
                lmbDragItem = carriedBefore;
            }
        } else {
            lmbDragItem = mc.player.containerMenu.getCarried();
        }
        
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickStart(Minecraft mc, int button, int action, int mods) {
        if (!(mc.screen instanceof AbstractContainerScreen)) {
            return EventResult.pass();
        }
        
        AbstractContainerScreen<?> screen = (AbstractContainerScreen<?>) mc.screen;
        Slot hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        if (hoveredSlot != null && mc.gameMode != null) {
            AbstractContainerMenu menu = mc.player.containerMenu;
            int containerId = menu.containerId;
            
            ItemStack carriedBefore = menu.getCarried();
            
            mc.gameMode.handleInventoryMouseClick(containerId, hoveredSlot.index, 1, ClickType.PICKUP, mc.player);
            
            rmbDragItem = menu.getCarried();
            
            if (!ItemStack.matches(carriedBefore, rmbDragItem)) {
                rmbSlotPassCounts.put(hoveredSlot, 1);
            }
        } else {
            rmbDragItem = mc.player.containerMenu.getCarried();
        }
        
        rmbSlotPassCounts.clear();
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleLeftClickEnd(Minecraft mc, int button, int action, int mods) {
        lmbDragItem = ItemStack.EMPTY;
        lmbShiftDragMode = false;
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleRightClickEnd(Minecraft mc, int button, int action, int mods) {
        if (rmbSlotPassCounts.isEmpty()) {
            return EventResult.pass();
        }
        
        AbstractContainerMenu menu = mc.player.containerMenu;
        int containerId = menu.containerId;
        
        for (Map.Entry<Slot, Integer> entry : rmbSlotPassCounts.entrySet()) {
            Slot slot = entry.getKey();
            int passCount = entry.getValue();
            
            if (passCount <= 0) {
                continue;
            }
            
            for (int i = 0; i < passCount; i++) {
                if (mc.gameMode != null) {
                    ItemStack carriedBefore = menu.getCarried();
                    if (carriedBefore.isEmpty()) {
                        break;
                    }
                    
                    mc.gameMode.handleInventoryMouseClick(containerId, slot.index, 1, ClickType.PICKUP, mc.player);
                    
                    ItemStack carriedAfter = menu.getCarried();
                    if (ItemStack.matches(carriedBefore, carriedAfter)) {
                        break;
                    }
                }
            }
        }
        
        rmbSlotPassCounts.clear();
        rmbDragItem = ItemStack.EMPTY;
        return EventResult.interruptDefault();
    }
    
    private static EventResult handleWheelScroll(Minecraft mc, double scrollDelta) {
        if (!(mc.screen instanceof AbstractContainerScreen)) {
            return EventResult.pass();
        }
        
        AbstractContainerScreen<?> screen = (AbstractContainerScreen<?>) mc.screen;
        Slot hoveredSlot = getHoveredSlot(screen, lastMouseX, lastMouseY);
        
        if (hoveredSlot == null || mc.gameMode == null) {
            return EventResult.pass();
        }
        
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean isPush = scrollDelta < 0;
        
        if (config.wheelScrollDirection == 1) {
            isPush = !isPush;
        } else if (config.wheelScrollDirection == 2) {
            if (hoveredSlot.container == mc.player.getInventory()) {
                isPush = scrollDelta < 0;
            } else {
                isPush = scrollDelta > 0;
            }
        }
        
        if (isPush) {
            performWheelPush(mc, hoveredSlot);
        } else {
            performWheelPull(mc, hoveredSlot);
        }
        
        return EventResult.interruptDefault();
    }
    
    private static boolean isPointNearLine(int x1, int y1, int x2, int y2, int px, int py, double maxDist) {
        double lineLen = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        if (lineLen == 0) {
            return Math.sqrt((px - x1) * (px - x1) + (py - y1) * (py - y1)) <= maxDist;
        }
        
        double t = Math.max(0, Math.min(1, ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / (lineLen * lineLen)));
        double nearestX = x1 + t * (x2 - x1);
        double nearestY = y1 + t * (y2 - y1);
        
        return Math.sqrt((px - nearestX) * (px - nearestX) + (py - nearestY) * (py - nearestY)) <= maxDist;
    }
    
    private static void performShiftClick(Minecraft mc, Slot slot) {
        if (mc.gameMode == null || mc.player == null) {
            return;
        }
        
        AbstractContainerMenu menu = mc.player.containerMenu;
        int containerId = menu.containerId;
        
        mc.gameMode.handleInventoryMouseClick(containerId, slot.index, 0, ClickType.QUICK_MOVE, mc.player);
    }
    
    private static void performMerge(Minecraft mc, Slot slot) {
        if (mc.gameMode == null) {
            return;
        }
        
        AbstractContainerMenu menu = mc.player.containerMenu;
        int containerId = menu.containerId;
        
        ItemStack slotItem = slot.getItem();
        ItemStack carried = menu.getCarried();
        
        if (carried.isEmpty() || !ItemStack.isSameItemSameTags(carried, slotItem)) {
            return;
        }
        
        int maxStackSize = carried.getMaxStackSize();
        int totalAmount = carried.getCount() + slotItem.getCount();
        
        if (totalAmount <= maxStackSize) {
            mc.gameMode.handleInventoryMouseClick(containerId, slot.index, 0, ClickType.PICKUP, mc.player);
        } else {
            int remaining = totalAmount - maxStackSize;
            slotItem.setCount(remaining);
            carried.setCount(maxStackSize);
            slot.setChanged();
        }
        
        lmbDragItem = menu.getCarried();
    }
    
    private static void performWheelPush(Minecraft mc, Slot sourceSlot) {
        if (sourceSlot.container != mc.player.getInventory()) {
            return;
        }
        
        ItemStack sourceItem = sourceSlot.getItem();
        if (sourceItem.isEmpty()) {
            return;
        }
        
        Slot targetSlot = findWheelTargetSlot(mc, sourceItem, false);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static void performWheelPull(Minecraft mc, Slot sourceSlot) {
        if (sourceSlot.container == mc.player.getInventory()) {
            return;
        }
        
        ItemStack sourceItem = sourceSlot.getItem();
        if (sourceItem.isEmpty()) {
            return;
        }
        
        Slot targetSlot = findWheelTargetSlot(mc, sourceItem, true);
        
        if (targetSlot != null) {
            transferItem(mc, sourceSlot, targetSlot);
        }
    }
    
    private static Slot findWheelTargetSlot(Minecraft mc, ItemStack item, boolean searchPlayerInventory) {
        AbstractContainerMenu menu = mc.player.containerMenu;
        CatalystConfig config = CatalystConfig.getInstance();
        
        boolean reverse = config.wheelSearchOrder == 1;
        
        int start = reverse ? menu.slots.size() - 1 : 0;
        int end = reverse ? -1 : menu.slots.size();
        int step = reverse ? -1 : 1;
        
        for (int i = start; i != end; i += step) {
            Slot slot = menu.getSlot(i);
            boolean isPlayerInventory = slot.container == mc.player.getInventory();
            
            if (searchPlayerInventory != isPlayerInventory) {
                continue;
            }
            
            if (slot.mayPlace(item)) {
                ItemStack slotItem = slot.getItem();
                if (slotItem.isEmpty()) {
                    return slot;
                } else if (ItemStack.isSameItemSameTags(item, slotItem) && slotItem.getCount() < slotItem.getMaxStackSize()) {
                    return slot;
                }
            }
        }
        
        return null;
    }
    
    private static void transferItem(Minecraft mc, Slot sourceSlot, Slot targetSlot) {
        if (mc.gameMode == null) {
            return;
        }
        
        AbstractContainerMenu menu = mc.player.containerMenu;
        int containerId = menu.containerId;
        
        ItemStack sourceItem = sourceSlot.getItem();
        ItemStack targetItem = targetSlot.getItem();
        
        if (targetItem.isEmpty()) {
            mc.gameMode.handleInventoryMouseClick(containerId, sourceSlot.index, 0, ClickType.PICKUP, mc.player);
            mc.gameMode.handleInventoryMouseClick(containerId, targetSlot.index, 0, ClickType.PICKUP, mc.player);
        } else if (ItemStack.isSameItemSameTags(sourceItem, targetItem)) {
            int maxStackSize = sourceItem.getMaxStackSize();
            int total = sourceItem.getCount() + targetItem.getCount();
            
            if (total <= maxStackSize) {
                mc.gameMode.handleInventoryMouseClick(containerId, sourceSlot.index, 0, ClickType.PICKUP, mc.player);
                mc.gameMode.handleInventoryMouseClick(containerId, targetSlot.index, 0, ClickType.PICKUP, mc.player);
            } else {
                int remaining = total - maxStackSize;
                sourceItem.setCount(remaining);
                targetItem.setCount(maxStackSize);
                sourceSlot.setChanged();
                targetSlot.setChanged();
            }
        }
    }
}
