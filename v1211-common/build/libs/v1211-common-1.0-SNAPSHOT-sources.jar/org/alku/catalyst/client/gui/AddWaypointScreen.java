package org.alku.catalyst.client.gui;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5321;
import org.alku.catalyst.client.waypoint.Waypoint;
import org.alku.catalyst.client.waypoint.WaypointManager;

public class AddWaypointScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    
    private final class_2338 pos;
    private final class_5321<class_1937> dimension;
    private final int color;
    
    private class_342 nameBox;
    
    public AddWaypointScreen(class_2338 pos, class_5321<class_1937> dimension, int color) {
        super(class_2561.method_43471("catalyst.gui.waypoints.add"));
        this.pos = pos;
        this.dimension = dimension;
        this.color = color;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int centerX = this.field_22789 / 2;
        int startY = 60;
        
        nameBox = new class_342(this.field_22793, centerX - 100, startY, 200, 20, class_2561.method_43471("catalyst.gui.waypoints.name"));
        nameBox.method_1880(50);
        nameBox.method_1852("Waypoint");
        method_25429(nameBox);
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.waypoints.create"),
            button -> createWaypoint()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + 50, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.cancel"),
            button -> this.method_25419()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + 80, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }
    
    private void createWaypoint() {
        String name = nameBox.method_1882().trim();
        if (name.isEmpty()) {
            name = "Waypoint";
        }
        
        Waypoint waypoint = new Waypoint(name, pos, dimension, color);
        WaypointManager.getInstance().addWaypoint(waypoint);
        
        this.method_25419();
    }
    
    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        
        String posText = String.format("Position: %d, %d, %d", pos.method_10263(), pos.method_10264(), pos.method_10260());
        guiGraphics.method_25303(this.field_22793, posText, this.field_22789 / 2 - 100, 45, 0xAAAAAA);
        
        nameBox.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(new WaypointScreen());
        }
    }
}
