package org.alku.catalyst.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.alku.catalyst.client.waypoint.Waypoint;
import org.alku.catalyst.client.waypoint.WaypointManager;

public class WaypointDetailScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    
    private final Waypoint waypoint;
    
    public WaypointDetailScreen(Waypoint waypoint) {
        super(class_2561.method_43470(waypoint.getName()));
        this.waypoint = waypoint;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int centerX = this.field_22789 / 2;
        int startY = 80;
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.waypoints.teleport"),
            button -> teleportToWaypoint()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.waypoints.delete"),
            button -> deleteWaypoint()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + 30, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.back"),
            button -> this.method_25419()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + 60, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }
    
    private void teleportToWaypoint() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.field_3944.method_45730("tp " + waypoint.getX() + " " + waypoint.getY() + " " + waypoint.getZ());
        }
        this.method_25419();
    }
    
    private void deleteWaypoint() {
        WaypointManager.getInstance().removeWaypoint(waypoint);
        this.method_25419();
    }
    
    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        
        String posText = String.format("X: %d, Y: %d, Z: %d", waypoint.getX(), waypoint.getY(), waypoint.getZ());
        guiGraphics.method_25300(this.field_22793, posText, this.field_22789 / 2, 45, 0xAAAAAA);
        
        String dimText = "Dimension: " + waypoint.getDimension().method_29177().toString();
        guiGraphics.method_25300(this.field_22793, dimText, this.field_22789 / 2, 60, 0xAAAAAA);
        
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(new WaypointScreen());
        }
    }
}
