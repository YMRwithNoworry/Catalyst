package org.alku.catalyst.client.feature;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.alku.catalyst.config.CatalystConfig;

public class AutoWeapon {
    private static int originalSlot = -1;
    private static boolean wasAttacking = false;
    private static long lastSwitchTime = 0;
    private static final long RESTORE_DELAY = 500;
    
    public static void checkAndSwitch(class_310 mc) {
        if (!CatalystConfig.getInstance().autoWeaponEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null) {
            return;
        }
        
        if (mc.field_1765 instanceof net.minecraft.class_3966 entityHitResult) {
            class_1297 target = entityHitResult.method_17782();
            if (target instanceof class_1309) {
                if (CatalystConfig.getInstance().autoWeaponRestore && !wasAttacking) {
                    originalSlot = player.method_31548().field_7545;
                }
                
                int bestSlot = findBestWeaponSlot(player);
                if (bestSlot >= 0 && bestSlot != player.method_31548().field_7545) {
                    player.method_31548().field_7545 = bestSlot;
                    lastSwitchTime = System.currentTimeMillis();
                }
            }
        }
    }
    
    public static void tick(class_310 mc) {
        if (!CatalystConfig.getInstance().autoWeaponEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null) {
            return;
        }
        
        boolean isAttacking = mc.field_1690.field_1886.method_1434();
        
        if (isAttacking) {
            wasAttacking = true;
        } else {
            if (wasAttacking && originalSlot >= 0 && CatalystConfig.getInstance().autoWeaponRestore) {
                player.method_31548().field_7545 = originalSlot;
                originalSlot = -1;
            }
            wasAttacking = false;
        }
    }
    
    private static int findBestWeaponSlot(class_746 player) {
        class_1661 inventory = player.method_31548();
        
        int lockedSlot = CatalystConfig.getInstance().autoWeaponLockedSlot;
        if (lockedSlot >= 0 && lockedSlot < 9) {
            return lockedSlot;
        }
        
        int bestSlot = inventory.field_7545;
        double bestDamage = getWeaponDamage(player.method_6047());
        
        for (int i = 0; i < 9; i++) {
            if (i == inventory.field_7545) {
                continue;
            }
            
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) {
                continue;
            }
            
            double damage = getWeaponDamage(stack);
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }
        
        return bestSlot;
    }
    
    private static double getWeaponDamage(class_1799 stack) {
        var item = stack.method_7909();
        if (item instanceof class_1831 tiered) {
            return tiered.method_8022().method_8028();
        }
        return 0.0;
    }
}
