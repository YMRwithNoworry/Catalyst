package org.alku.catalyst.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class KeybindConfigScreen extends class_437 {
    private final class_437 parent;
    private final String keyName;
    
    public KeybindConfigScreen(class_437 parent, String keyName) {
        super(class_2561.method_43471("catalyst.gui.keybind_config"));
        this.parent = parent;
        this.keyName = keyName;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
    }
    
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            KeybindManager.setKey(keyName, GLFW.GLFW_KEY_UNKNOWN);
            this.field_22787.method_1507(parent);
            return true;
        }
        
        KeybindManager.setKey(keyName, keyCode);
        this.field_22787.method_1507(parent);
        return true;
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button >= 0 && button <= 2) {
            int keyCode = button + 100;
            KeybindManager.setKey(keyName, keyCode);
            this.field_22787.method_1507(parent);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(graphics, mouseX, mouseY, partialTick);
        
        String currentKey = KeybindManager.getBoundKey(keyName);
        
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 60, 0xFFFFFF);
        
        class_2561 keyNameText = class_2561.method_43471("key.catalyst." + keyName);
        graphics.method_27534(this.field_22793, keyNameText, this.field_22789 / 2, this.field_22790 / 2 - 30, 0xAAAAAA);
        
        class_2561 currentKeyText = class_2561.method_43470(currentKey).method_27694(style -> style.method_36139(0xFFFF55));
        graphics.method_27534(this.field_22793, currentKeyText, this.field_22789 / 2, this.field_22790 / 2, 0xFFFFFF);
        
        graphics.method_27534(this.field_22793, class_2561.method_43471("catalyst.gui.press_key"), this.field_22789 / 2, this.field_22790 / 2 + 40, 0x55FF55);
        graphics.method_27534(this.field_22793, class_2561.method_43471("catalyst.gui.escape_to_clear"), this.field_22789 / 2, this.field_22790 / 2 + 60, 0xFF5555);
        
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }
    
    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
