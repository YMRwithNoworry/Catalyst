package org.alku.catalyst.client.feature;

import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.alku.catalyst.config.CatalystConfig;

public class AutoSwim {
    
    public static void tick(class_310 mc) {
        if (!CatalystConfig.getInstance().autoSwimEnabled) {
            return;
        }
        
        class_746 player = mc.field_1724;
        if (player == null) {
            return;
        }
        
        if (shouldSwim(player, mc)) {
            if (!player.method_5681()) {
                player.method_5796(true);
                if (mc.method_1562() != null) {
                    mc.method_1562().method_52787(new class_2848(player, class_2848.class_2849.field_12981));
                }
            }
        }
    }
    
    private static boolean shouldSwim(class_746 player, class_310 mc) {
        if (player.method_5681()) {
            return true;
        }
        
        if (!player.method_5799()) {
            return false;
        }
        
        if (player.method_5715()) {
            return false;
        }
        
        if (mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1903.method_1434()) {
            return true;
        }
        
        return false;
    }
}
