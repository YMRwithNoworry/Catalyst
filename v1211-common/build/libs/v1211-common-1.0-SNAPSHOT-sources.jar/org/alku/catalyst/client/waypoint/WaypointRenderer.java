package org.alku.catalyst.client.waypoint;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5321;
import org.joml.Matrix4f;

public class WaypointRenderer {
    
    public static void renderWaypoints(float partialTick) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        
        class_5321<class_1937> currentDimension = mc.field_1687.method_27983();
        class_243 cameraPos = mc.field_1773.method_19418().method_19326();
        
        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();
        
        class_4587 poseStack = new class_4587();
        
        for (Waypoint wp : WaypointManager.getInstance().getWaypointsForDimension(currentDimension)) {
            renderWaypointLabel(poseStack, wp, cameraPos, bufferSource);
        }
    }
    
    private static void renderWaypointLabel(class_4587 poseStack, Waypoint waypoint, class_243 cameraPos, class_4597 bufferSource) {
        class_310 mc = class_310.method_1551();
        class_327 font = mc.field_1772;
        
        class_2338 pos = waypoint.getPos();
        double x = pos.method_10263() - cameraPos.field_1352;
        double z = pos.method_10260() - cameraPos.field_1350;
        
        String initial = WaypointManager.getInstance().getDisplayInitial(waypoint);
        
        poseStack.method_22903();
        poseStack.method_22904(x, 260, z);
        poseStack.method_22907(mc.field_1773.method_19418().method_23767());
        poseStack.method_22905(-0.025f, -0.025f, 0.025f);
        
        float r = ((waypoint.getColor() >> 16) & 0xFF) / 255.0f;
        float g = ((waypoint.getColor() >> 8) & 0xFF) / 255.0f;
        float b = (waypoint.getColor() & 0xFF) / 255.0f;
        
        int textColor = ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255) | 0xFF000000;
        
        int textWidth = font.method_1727(initial);
        int textHeight = font.field_2000;
        
        Matrix4f matrix = poseStack.method_23760().method_23761();
        
        font.method_27521(initial, -textWidth / 2.0f, -textHeight / 2.0f, textColor, false, matrix, bufferSource, class_327.class_6415.field_33993, 0, 15728880);
        
        poseStack.method_22909();
    }
}
