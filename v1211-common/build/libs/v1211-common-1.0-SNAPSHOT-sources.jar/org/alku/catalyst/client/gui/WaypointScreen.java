package org.alku.catalyst.client.gui;

import org.alku.catalyst.client.waypoint.Waypoint;
import org.alku.catalyst.client.waypoint.WaypointManager;

import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class WaypointScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 24;
    
    private int scrollOffset = 0;
    private int maxVisible = 10;
    
    public WaypointScreen() {
        super(class_2561.method_43471("catalyst.gui.waypoints.title"));
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int centerX = this.field_22789 / 2;
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.waypoints.add_current"),
            button -> addCurrentPosition()
        ).method_46434(centerX - BUTTON_WIDTH / 2, this.field_22790 - 50, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.back"),
            button -> this.method_25419()
        ).method_46434(centerX - BUTTON_WIDTH / 2, this.field_22790 - 25, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        rebuildWaypointButtons();
    }
    
    private void rebuildWaypointButtons() {
        method_37067();
        
        int centerX = this.field_22789 / 2;
        int startY = 50;
        
        int index = 0;
        for (Waypoint wp : WaypointManager.getInstance().getWaypoints()) {
            if (index >= scrollOffset && index < scrollOffset + maxVisible) {
                int y = startY + (index - scrollOffset) * BUTTON_SPACING;
                method_37063(new WaypointButton(
                    centerX - BUTTON_WIDTH / 2, y, BUTTON_WIDTH, BUTTON_HEIGHT, wp
                ));
            }
            index++;
        }
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("catalyst.gui.waypoints.add_current"),
            button -> addCurrentPosition()
        ).method_46434(centerX - BUTTON_WIDTH / 2, this.field_22790 - 50, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        
        method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.back"),
            button -> this.method_25419()
        ).method_46434(centerX - BUTTON_WIDTH / 2, this.field_22790 - 25, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }
    
    private void addCurrentPosition() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1687 != null) {
            class_2338 pos = mc.field_1724.method_24515();
            int color = generateRandomColor();
            
            mc.method_1507(new AddWaypointScreen(pos, mc.field_1687.method_27983(), color));
        }
    }
    
    private int generateRandomColor() {
        Random random = new Random();
        return random.nextInt(0xFFFFFF + 1);
    }
    
    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);
        
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 0xFFFFFF);
        
        if (WaypointManager.getInstance().getWaypoints().isEmpty()) {
            guiGraphics.method_27534(this.field_22793, 
                class_2561.method_43471("catalyst.gui.waypoints.empty"), 
                this.field_22789 / 2, this.field_22790 / 2, 0x888888);
        }
        
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    private static class WaypointButton extends class_4185 {
        private final Waypoint waypoint;
        
        public WaypointButton(int x, int y, int width, int height, Waypoint waypoint) {
            super(x, y, width, height, 
                class_2561.method_43470(waypoint.getName() + " [" + waypoint.getX() + ", " + waypoint.getY() + ", " + waypoint.getZ() + "]"),
                button -> {},
                class_4185.field_40754);
            this.waypoint = waypoint;
        }
        
        @Override
        public void method_25306() {
            class_310 mc = class_310.method_1551();
            mc.method_1507(new WaypointDetailScreen(waypoint));
        }
    }
}
