package org.alku.catalyst.mixin;

import org.joml.Matrix4f;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.alku.catalyst.client.waypoint.WaypointRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WaypointRenderMixin {
    
    @Inject(
        method = {"renderLevel", "m_109599_"},
        at = @At("RETURN"),
        remap = false
    )
    private void afterRenderLevel(class_9779 deltaTracker, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightTexture, Matrix4f projectionMatrix, Matrix4f projectionMatrix2, CallbackInfo ci) {
        WaypointRenderer.renderWaypoints(deltaTracker.method_60637(true));
    }
}
