package org.alku.catalyst.mixin;

import net.minecraft.class_310;
import net.minecraft.class_437;
import org.alku.catalyst.client.gui.CatalystConfigScreen;
import org.alku.catalyst.config.CatalystConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.MouseHandler")
public class MouseHandlerMixin {
    
    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void onScroll(long windowPointer, double xOffset, double yOffset, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        class_437 screen = mc.field_1755;
        if (screen instanceof CatalystConfigScreen) {
            CatalystConfig config = CatalystConfig.getInstance();
            float oldScale = config.guiScale;
            config.guiScale += (float) yOffset * 0.1f;
            config.guiScale = Math.max(0.5f, Math.min(2.0f, config.guiScale));
            
            if (oldScale != config.guiScale) {
                config.save();
                mc.method_1507(new CatalystConfigScreen(null));
            }
            ci.cancel();
        }
    }
}
